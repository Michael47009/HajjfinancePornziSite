<?php
	include 'config.php';
	include 'cdn.php';

$uid = $_SESSION['uid'];


if(isset($_GET['req'])) {
	//echo 'twitter task';
	 $chk = $conn->query("select * from task where uid='$uid' and task_name='twitter'");

	 if($chk->num_rows>0) {
	 	//user did task
	 	echo '<h2>you have aleady done this task</h2>';
	 }
	 else {
	 	$conn->query("insert into task(uid,task_name,task_status) values('$uid','twitter','done')"); 

	 	//get hfc bal
	 	$get_prev_hfc = $conn->query("select * from user_logins where uid='$uid'");

		if($get_prev_hfc->num_rows>0) {
			while($tr=$get_prev_hfc->fetch_assoc()) {

						$hf = 2000;
					
						$new_hfc = $tr['hfsc'] + $hf;
						echo $new_hfc;

$update_hfc = $conn->query("update user_logins set hfsc='$new_hfc' where uid='$uid'")or die($conn->error);

?>

<script type="text/javascript">
	window.location.href='https://x.com/rnaeu_?s=21';
</script>
<?php
					}	
				}

	 }
}
?>
<style type="text/css">
	body {
		background: #333333;
		height: 100%;
		
		font-family: "Roboto", sans-serif;
		color: white;
	}	.navbar {
 display: block;
  margin-left: 10%;
  border-radius: 14px;
  background-color: #262626;
  overflow: hidden;
  position: fixed;
  bottom: 0;
  width: 80%;
}

/* Style the links inside the navigation bar */
.navbar a {
  float: left;
  display: block;
  color: orange;
  text-align: center;
  padding: 20px 20px;
  text-decoration: none;
  font-size: 17px;
}
1 {
	color: orange;
}
/* Change the color of links on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.head-one {
	display: block;
	margin-left: 40%;

	margin-top: 12%;
}
</style>

<?php

	if(isset($_SESSION['uid'])) {



		

?>

<body>
	<div class="head-one">
		<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA8FBMVEX///8AKH1UWqhZWVkAAHIAIXpUXZbb2+UAJ31QUFAAEXamqsgAGnpRV6eFia0AAG1TU1P19fUAHXlBQUHl5u4AFXeIiIhpaWmbo7/r7vXJycmxsbFOVKY1RolJSUlLS0tfX1/m5uZDSqI8PDyhoaHv7+/T09PFxcVubm4+RaC9v9m1t9R+gbopTJJIT6Nrb7KPj497e3u3t7fS0+aLj8Fyd7U1PJyipcuusdJbYasTNIMdPYnc3NzU1OR0e6XBxNRcZJZ/hKsnMJlJVY+WnL8AOYuFib5lcKA3Q4eVmsS2uc3Y2ep3e7bGx9+nqs0wMDDJsSsbAAALqklEQVR4nO2cC1viOBeAoYAUxgrlOmgXSgGlikWUi+Cgzuo4C8rs//83X9JrAq0UaE33e8777M7UUkLeJjknKXFiMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADkTc832lfd/41aRr+77z/S7IeoSFeHlAS4j30W/G98vD3n8f9Wa8Xx1awuUkiHqExjB9eBnp3uFlhIU4KgVRTLof1cEoTvcOojQlLZqKNS0gQaSoBtIZAiZAwVjsTgmwsIAQtTn6c/74/Pz45H1V5+T56Pd3H8VdjaPWUUUV58GfuUIqVUg+e131lCsXUoVswUcfXEgRU+wv0B/fknGd7E/3i0o5Hr/Mp2Y+aj8dBVrBQ3nj8J9x3jDkc+6N9PPYeD2eW24vsjReBFrFw5iMcWBI5+KfG1h3IJ569lHo5d8HTgADZP73Ff4rnbQMs99cr7NfTx35KXakRCVniJoxZII2rI37wVXyID7GRvIK2jA2UaMxC79UzHoEbigKkZjbiKpgHgVuGLtXopAy3lQr5AVvGBOUg9ebBzNXp9ZhCIZ/NC6ISh5EX7myDkMwjI21q+0XhcpKUezjMAyHknp4JQ9C0JyAHoZhWmHciCtFc+J5GIaxqTDdflGITKUP54dQDP9oTMPpXNGIj09n9zUU08urbwZXS/pxXUkVPmLs6EkKsdJLJ2f7GHa+v2Rz2TImW0A3KfdCTWSmQpCPR3akpgnks03US2c7G3Z+58opY1XF87PrePx6VsiSigtJ+xNO9X1wr1GBDo9DQ/H4tVbapJbdNFyWC9bJOBKcYctZ4TdR6kpjGGum9MwYG/IzvT3KOTfiG4aPSd4RRM1nKPI5otSayqmsumlNFRTyZz2W8rP4dizDI7tV9S6qNyCPVKmnIArHLCVe0cPQyhY+FE3D31niHJK7NjoqCjZko/UEidU3GeijqRWqaeijFQ3D70nyHNJ7wK2Ij8leGptInBBjg8bRydjK+NsVdcNSjjjDPzzwuiL+IXtCFnulcYwWwu8KRz8qcuY02xR1w+cCcQYbmsMwnv2L+pw0s4GI7q1EBTnHMD7jN7XWDImreXR99leqzM9+lZPJ3E/6eXFJ4aThl5pZvEkcvTwl6rylFbHho9OEs4fr70/z9/c5ZuM71hoah2weuk2FtVRMGn4+FrGh08z8rxOPj9BBhhyTlb4orN9awrBQLqeOy+uQhs7F/PHr55+EBJlMTUuat2Hq93cXvh0ThkszF/J86p8tn4QMlQD2B+wMCnEC/axvp/Xha9nszQ+/tn1NM0WG84BqvQurwwxPCobg9Sy1LdnhXsriS5qrT3qpH0O9y+IEWNgyxkRseB9UtXfgHhl6xVK/hnqe32ZYEzhOYrFERNNF7mDD2fVDapthCX2QxOIrGmwoULOPPXopXhPOthiikMbOUPOYl/o2jOOnFlsM71gaKu/kmb0M+fjDFsN7idE4RJFmbc6/XxvyqS2GC4lRLEXZgpOo7RJ7Gm6LNH2BUT7Ew4NOF/sZxvm/KF4e12ZoKp61sdhXi5ZtHDcmz+xpGE/RFHLUTByHUjbzUn1Ro5H3dl/DDZLkTBWPBjZrCzxdpKN4YIb8jHjTm8AxWh/qEYCamQZmGM85MwkRNyGjNT6O4tTj6AANnWGHA9pazP4yLrW1SX9wvZR4XjqUWC2e9C8U6HwRmCGx6hexIKvnpXjtTcXx4GKps8tY7yiMAo3xOJF8lBlQPjzOEdukcTjjpLewVTww7q+zIbuU5TcbgcRjTvNyRPL8k+iSaTwSWA1DNEbG+sc7KfGflFnnY/ddzrvPS/VuwrHb1a53Ic759Y8nYx93POexG39nw5LehIyyIcboppqTrJbJ7PFx1ktwd8OexLSTWqGcnDR2licn3zxrvKvhu7Je/pdjDBPfoc4xfPFlOBV2Kj4MjFDHqT6fSNt79eMzP4ZXRhOq7x6vfwkj/S773Q7ykrIMy+nthqKR7BnGGczKHCn+ZsYnxFczr4VthkaY4RTGv3VhDBVO9bW7bknsqLF7rJfhvXHzBFa7FCzujHpwip+kXCsTX35b35B6GBqpkOPYb/Q2sr7P0UJtTph9Zihyu5QbKmY45TQ/MX1O7qAxN4i5G46MQcg4kBoMzbpofh68U41otKKr4ZsRR9nmQhtzJHKqj+fStRwxEnld0c1wYZcZiV+zfNpFcUnt9MLhxsVwYpXIOlNYDDWrQj6+P3lN8jzVUTcN7RaMRh/FmHEPKfrI/K85ar/ULBVf64lDS5CLzq8CW7kLhRsf+ySXWSrcxF+oV8WR1SM4lcWjfA8undvu499VKB0lU44g/cSjxElWUQqrfbOu2LGBEzQfk5Cno1y2kOIRhRy14+tSEWxBNrv1PLGjDepcbz6GT235eISizOyZbEGxZ98oX/39a+k5iprgcy4p0rdiJdk9lJPYz9Y2+HAUBaW3+4OH0shpwEgKOjMtjptOueliN8facCxEXRApmo0g9KdCvz+d+HcsLZwOgLs5y990+pSJ8XhTGOEHG31OefP3/GbeU/H+KlswalGUZKUKSA01oLm4U6TJtm+N0hPJzBCmoqBGKg+uU5pyqAE5S5ETJGW6uPPKHuLdYqo48VNXlAQWW0l3YSFgu/7UjhtIUukPL9/pUVm7uxr2FUUiwouuqIwiMxf1ZEXYOZaapo6Ffm+4WCyGH31prGqatHHZ+iarqCJONhVNUUHCCF4v75NG2ZDuKx4Sn6FxUf8HBUlW0x0dBY2LyHreN6td2lFQpv+JAbjGvDd2CyabepI6Yv7Yd0/E+76qfS4paGp/h+ldBKndjyTFwxJlSqn/Jwr/xs6BiPM/PWWsaHqe0EFHKD+qH5O7/3Tr0Yjz1WTx1hv1+6OP3ttisppHf+4CAAAAAH45v7g9/WH9IDabzQ510EEHZuLDh877mj/Oz89/kCWJzqV0+RfnIdTbJ+JNq5HJZOqtC7M6/9aLMj5ot8yDarHe6hgvDor1fy2Ds3/rDUS9Vb2wCztr2eU454qo/Eaj1Q5R4jPEfCaRSOQTibrZGCL6uYgPugnzAP1dNa+u5BNF2xBdmM+jdybqNzHnXOaU/oBBwyg/cxauiCcVLDeoVFstu0roBO6KCWyIDpqNRL7tXE0a5ivtdhUZFH8459YMz9DL9W6lW2w1Y0wQi8hDP7Ir1s7rtWzie48PLhqJujWK1gwb58b1+Rvn3Jph1eod6533q2jKsl09k1OjzZBYVT9ABg3Lys2wU0Rt6ZyjDUV0mxphCmylI3flxlqca+k1bufz6L+KPh4H1ktuhs36Z20oMxyBBoNuF40TqguhSsm4exVRR5WxcMYOg26G+Jz3OGyjeJRJnDFcZjXlLhoqjTxxn1G3rItITEZhtSg2iwmnkdcjzeCmguJk3b4DLrFUxrE6k2mzc2wOZBzxG137DBqI9R/NOup6Moox542EHWY3skUCZ4uq4+RiKFaK+Jqu3AnT4nPOB3Wcr+yA00TVvLjIZG5jg3zmFlXaHoYbho1inXynmyEq7ybfqHarcngG2+lUUG3rdj+SUQxt5xvN2BmKNjd5IlKsj8ML8RynA3sYuxoi2nK3W2c4cYvpaatop2TkMUD/i7i/Dgb2bCfmGmlQKLWnPJ6GsXa3W70Nq/K+QCmhaA+U20xCrua7eqpDSTHhXOYWS9FbW8S5NUPzlTNkyCjnV9rnHbGDY7psn2viiY4+U5PxwYC42sXwJu9Y4fjavsBYDXYzuOiI4kWmyyrUiNVuplgv4mFIdCI8JW3gWg/WpsxuhqcZKuMn8hmM1azdPC4fJdYqo7XFKZ7244aqkxXA03HdBLdtsUm94BiipKK3HZoDyda5TMLEvKzTssonesKXIt4O8BJIvqFm/rdytarnx3N0UCVeuKlWE6JzkayHxwo62XTeaGBddlqR8RKrwjSQdjrhzjfEDsNkDwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPw/8j+wODSaUh6WCAAAAABJRU5ErkJggg==" width='25%' style='border-radius: 100%;'>

	</div>
		<div class="nil">
			<br>
			<h2>Invite friends</h2>
			<h6>You and your friend will get bonuses.</h6>


			<br>
			<button class="invite">send invite</button>

		</div>
<br><br>

		<div class="task-bar">
			<button class="btn-one" id="btn-one"> Referals</button>
			<button  id="btn-two" class="btn-two">Task</button>
			<button id="btn-three" class="btn-three">Trans.</button>
		</div>


<script type="text/javascript">
	//$(".Referals").hide();
	//$(".task").hide();
	//$(".transaction").hide();

	var elm_one= document.getElementById("btn-one");


	elm_one.addEventListener("click", function() {
		$(".task").hide();
		$(".transaction").hide();
		$(".Referals").show();
	});

	var elm_two = document.getElementById("btn-two");


	elm_two.addEventListener("click", function() {
		$(".Referals").hide();
		$(".transaction").hide();
		$(".task").show();
	});


var elm_three= document.getElementById("btn-three");


	elm_three.addEventListener("click", function() {
		$(".transaction").show();
		$(".task").hide();
		$(".Referals").hide();
		

	});


</script>

<style>
	.Referals {
		text-align: left;	

	}
	.Referals div {
		border:1px solid gray;
		width: 80%;
		display: block;
		margin: auto;
		border-radius: 7px;
		padding: 5%;
	}
	h3 {
		text-align: center;
		color: cornflowerblue;
	}
</style>
		<div class="display-panel">
<br>

<h3>
	Total Refers: 
<?php
	$get_earnings = $conn->query("select sum(earned) as sm from earnings where uid='$uid'") or die($conn->error);

												$row = mysqli_fetch_assoc($get_earnings); 
												$sum = $row['sm'];

												echo $sum/2500;

												echo " Earned: NGN ".$sum;

												?></h3>
			<div class="Referals">
					<?php 

				$get_users_refered = $conn->query("select * from referals where add_id='$uid' order by join_date desc"); 

					if($get_users_refered->num_rows>0)
					 {
						while($loop = $get_users_refered->fetch_assoc()) {

								?>

								<div> <b><?php echo $loop['join_name'];?>

								(<?php echo base64_encode($loop['join_id']);?>)

								<br>Coin balance: <span id='cbal'><?php echo $loop['join_balance'];?></span>

								<script>

	var price = <?php echo $loop['join_balance'];?>;
	var formatted = Intl.NumberFormat(undefined, {
		style:"currency",
		currency:"USD",
	}).format(price);


	//document.getElementById("cbal").innerHTML=formatted;
</script>

							</b>

								<br>Reg date: <?php echo date("Y-m-d", strtotime($loop['join_date']));?>
								Earnings<p id="gr">+NGN 2,500 (1000 HFC)</p></div><br>




								<?php
							

						}
					}
					else {
						echo "";
					}

			?>
			</div>

			<div class="task">
					<h3 style='text-align:center;'>Task</h3>
				<a href="profile.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>">		<div class="cont">
						<i class="fa fa-credit-card" style="font-size:17px"></i> Add account number.<code>(+1000HFC)</code>
					</div></a><br>


					<a href="task.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>&status_code=SignIn&req=twitter_follow">
						<div class="cont">
						<i class="fa fa-twitter" style="font-size:17px"></i> Follow on Twitter.<code> (+2000HFC)</code>
<br>


			</div></a>
			<br>
<p>More task would be added soon...</p>
</div>

			<div class="transaction">
				<h3 style='text-align:center;'>Transaction</h3><br>
				<div class="btns">
	<a href="deposit.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>">	<button>Deposit  <i class="fa fa-credit-card" style="font-size:13px"></i></button></a>

	<a href="withdraw.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>">	<button>withdraw  <i class="fa fa-credit-card" style="font-size:13px"></i></button></a>


	

</div>
		
<br><fd>Deposits:</fd>
			<?php

				$get = $conn->query("select * from transactions where uid='$uid' and txn_type='deposit' order by txn_id desc");

				if($get->num_rows>0) {
					while($pool = $get->fetch_assoc()) {
						?>

<div class="history">						
			<div class="left"> <i class="fa fa-credit-card" style="font-size:20px"></i> <?php echo $pool['txn_type'];?> to account: <?php echo base64_encode($pool['uid']);?>
				<p><?php echo date("Y-m-d", strtotime($pool['txn_date']));?>
					
				</p>

		</div>
<style type="text/css">

</style>
			<div class="right"><?php echo $pool['txn_amount'];?><p><?php echo $pool['txn_type'];?>
				<span><?php 


				$query = $pool['txn_status'];
				switch($query) {
					case 'processing':
						echo '<or>'.$query.'</or>';
						break;
					case 'approved':
						echo '<gr>'.$query.'</gr>';
						break;
						case 'declined':
						echo "<rd style='color:red;'>".$query."</rd>";
						break;
				}

			?></span></p>
			</div><br>

			<br>

</div>
<br>
						<?php
					}
				}
			?>


		<fd>withdrawals:</fd><br>

				<?php

				$get = $conn->query("select * from transactions where uid='$uid' and txn_type!='deposit' order by txn_id desc");

				if($get->num_rows>0) {
					while($pool = $get->fetch_assoc()) {
						?>

<div class="history">						
			<div class="left-two"> <i class="fa fa-credit-card" style="font-size:20px"></i> <?php echo $pool['txn_type'];?> to account: <?php echo base64_encode($pool['uid']);?>
				<p><?php echo date("Y-m-d", strtotime($pool['txn_date']));?>
					
				</p>

		</div>
<style type="text/css">

</style>
			<div class="right-two"><?php echo $pool['txn_amount'];?><p>
				<span><?php 


				$query = $pool['txn_status'];
				switch($query) {
					case 'processing':
						echo '<or>'.$query.'</or>';
						break;
					case 'approved':
						echo '<gr>'.$query.'</gr>';
						break;
				}

			?></span></p>
			</div><br>

			<br><br><br>

</div>
<br>
						<?php
					}
				}
			?>

		
<br>

<style type="text/css">
	fd {
		margin-left: 6%;
	}
	.history .left-two {
		float: left;
		width: 70%;
	}
	.history .right-two {
		float: right;
	}
	.cont i {
		font-size: 21px;
	}
	.cont {
		border-radius: 12px;
		display: block;margin: auto;
		text-align: center;

		padding: 3%;
		width: 80%;
		font-size: larger;
		background: cornflowerblue;
		color: white;
	}
	or {
		color: orange;
	}
	gr {
		color: green;
	}
	.left p {
		font-size: 12px;
		margin-left: 15%;
		font-weight: lighter;
	}.right p {
		font-size: 12px;
		margin-right: 15%;
		font-weight: lighter;
	}
	.left-two p {
		font-size: 12px;
		margin-left: 15%;
		font-weight: lighter;
	}.right-two p {
		font-size: 12px;
		margin-right: 15%;
		font-weight: lighter;
	}
	.history .right {
		width: 37%;
	}
	.history {
		padding: 4%;
		
		width: 96%;
		border-radius: 14px;
		display: block;
		margin: auto;
		background: rgba(89,89,89, 0.3);
		
	}

.history .left {
	float: left;
}
.history .right {
	float: right;
}
	a {
		text-decoration: none;
		color: white;
	}
	.btns button {
		margin-left: 5%;
		border: hidden;
		border-radius: 3px;
		background: cornflowerblue;
		padding: 2%;
		width:30%;
	}
</style>
			</div>
			

<br><br><br><br><br><br><br><br><br><br><br><br>
		</div>

		<style type="text/css">

			#gr {
				color: green;
				font-weight: bolder;
			}
			.task-bar {
				column-count: 3;
				text-align: center;
				margin-left: 5%;
				margin-right: 5%;


			}
			.btn-one {
				border-top-left-radius: 14px;
				border-bottom-left-radius: 14px;
			}
			.btn-three {
				border-top-right-radius: 14px;
				border-bottom-right-radius: 14px;
			}
			.task-bar button {
				padding: 9%;
				display: inline-block;
				border: 1px solid #ccc;
				width: 100%;
				background: #333333;
				color: white;
			}
			.nil {

				text-align: center;
			}
			body {
				font-family: "Roboto", sans-serif;

			}
			.invite {
				color: black;
				background: orange;
				border: hidden;
				padding: 2%;
				border-radius: 17px;
				width: 40%;

			}
		</style>







 <div class="navbar">
  <a href="dashboard.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>&status_code=SignIn" class="active"><i class="fa fa-home" style="font-size:33px"></i><br></a>
  <a href="task.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>&status_code=SignIn"><i class="fa fa-globe" style="font-size:33px"></i><br></a>
  <a href="profile.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>&status_code=SignIn"><i class="fa fa-cog" style="font-size:33px"></i></a>
  <a href="signin.php"><i class="fa fa-power-off" style="font-size:33px"></i></a>
</div> 


<?php

if(isset($_REQUEST['deposit_req'])) {
	?>
	<script>
		//alert("sucess");
				$(".task").hide();
		$(".Referals").hide();
		$(".transaction").show();


	</script>
	<?php
}


if(isset($_REQUEST['w_req'])) {
	?>
	<script>
		//alert("sucess");
				$(".task").hide();
		$(".Referals").hide();
		$(".transaction").show();


	</script>

<?php
	}
}
	else {
		echo "<h1> PLease Login Again</h1>";
	}

?>