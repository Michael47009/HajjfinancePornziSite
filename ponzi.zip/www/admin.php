<?php
		include 'config.php';
		include 'cdn.php';


if (isset($_GET['delete_user'])) {
	// code...
	$uii = $_GET['delete_user'];

	$del = $conn->query("delete from user_logins where uid='$uii'");
	header("Location:admin.php");
}

?>
<style type="text/css">
	h5 {
		margin-left: 5%;
	}
	h3 {
		background: #;
	}
	body {
		background: #333333;
		color: white;
	}
	.panel {
		background: gray;
		width: 80%;
		padding: 4%;
		display: block;
		margin: auto;
	}
	gr {
		color: green;

	}
	or {
		color: orange;
	}
</style>
<h4>
HAJJ FINANCE CONTROL PANEL
</h4><hr>
<h5>useful links:<br>
 <a href="admin.php"> > admin home page</a><br>
  <a href="profits.php">> profit adder</a><br>
   <a href="deposit_admin.php">> deposit request</a><br>


</h5>
<br>
<div class="panel">
	<h4>Total users:</h4>
	<?php

		$sql = "SELECT COUNT(uid) AS row_count FROM user_logins";
		$result = $conn->query($sql);
	if ($result) {
    
		    if ($result->num_rows > 0) {
		        // Fetch the result as an associative array
		        $row = $result->fetch_assoc();
		        
		        // Output the row count
		        echo $row['row_count'];
		    } else {
		        echo "No users.";
		    }
} else {
   
    echo "Error: " . $conn->error;
}
	?>
</div><br>

<div class="panel">
	<h4>Total Invested:</h4>
	NGN<span id="fmt">
	<?php

		$sql = "SELECT SUM(txn_amount) AS row_count FROM transactions where txn_type='deposit'and txn_status='approved'";
		$result = $conn->query($sql);
	if ($result) {
    
		    if ($result->num_rows > 0) {
		        // Fetch the result as an associative array
		        $row = $result->fetch_assoc();
		        
		        // Output the row count
		        echo $row['row_count'];
		    } else {
		        echo "No users.";
		    }
} else {
   
    echo "Error: " . $conn->error;
}
	?></span>
	<script type="text/javascript">
	var pricel = document.getElementById('fmt').innerHTML;
		

	const price = pricel;
	const formatted = Intl.NumberFormat(undefined, {
		style:"currency",
		currency:"USD",
	}).format(price);


	console.log(formatted);
	document.getElementById("fmt").innerHTML = formatted.replace('$','');


</script>
</div><br>

<div class="panel">
	<h4>pending deposits:</h4>
	<?php

		$sql = "SELECT COUNT(txn_id) AS row_count FROM transactions where txn_type='deposit'and txn_status='processing'";
		$result = $conn->query($sql);
	if ($result) {
    
		    if ($result->num_rows > 0) {
		        // Fetch the result as an associative array
		        $row = $result->fetch_assoc();
		        
		        // Output the row count
		        echo $row['row_count'];
		    } else {
		        echo "No users.";
		    }
} else {
   
    echo "Error: " . $conn->error;
}
	?>
</div>
<style type="text/css">
	table {
		border: 1px solid white;
		border-radius: 7px;
	}
	tr {
		border: 1px solid white;
		padding: 1%;
	}
	td {
		border: 1px solid white;

		padding: 1%;
	}
	td button {
		border: hidden;
		background: red;
		padding: 5%;
		width: 50%;
		border-radius: 4px;

	}
	a {
		color: white;
	}
</style>
<br><br>
<table width="300%">

	<tr>
		<td width="15%">Full name</td>
		<td width="20%"> email</td>
		<td width="8%">hfc coins</td>
		
		<td width="15%">Bank details.</td>
		<td width="15%">Join date</td>
		<td width="15%">deposited?</td>
		<td width="15%">action</td>
	</tr>


<?php
	$gwt= $conn->query("select * from user_logins");
	if($gwt->num_rows>0) {
		while ($gwtt=$gwt->fetch_assoc()) {
			// code...

	
?>
	<tr>
		<td><?php echo $gwtt['uname'];?></td>
		<td><?php echo $gwtt['uemail'];?></td>
		<td><?php echo $gwtt['hfsc'];?></td>
		<td><?php echo $gwtt['bnk'].'<br>'.$gwtt['bnk_name'].'<br>'.$gwtt['bnk_no'];?></td>
		<td><?php echo $gwtt['uregdate'];?></td>
		<td><?php 

		//check deposit
		$ui = $gwtt['uid'];
		$chk = $conn->query("select * from transactions where uid='$ui' and txn_status='approved' limit 1") ;
			if($chk->num_rows>0) {
				while ($vb=$chk->fetch_assoc()) {
					// code...
					echo '<gr>Deposited</gr>';


				}
			}
			else {
				echo "<or>not deposit.</or>";
			}
	?></td>
		<td>

<a href="admin.php?delete_user=<?php echo $gwtt['uid'];?>">


<button>Delete</button>
</a>
	
				

			</td>
	</tr>
<?php

	}
	}
?>
</table>