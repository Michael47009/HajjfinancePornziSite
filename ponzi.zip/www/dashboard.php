<?php

		include 'config.php';
		include 'cdn.php';

$_SESSION['uid'] = '';



		if(isset($_GET['status_code'])) {
			//one for sign up and two for login
			
		
			$errmsg = "";

				switch ($_GET['status_code']) {
					
					case 'signup':
						// check if user details are correct and set session...

					$mail = $_GET['mail'];

					
						$chk = $conn->query("select * from user_logins where uemail='$mail' ");

									if($chk->num_rows>0) {
										while ($row = $chk->fetch_assoc()) {

											$_SESSION['uid'] = $row['uid'];

											$put = $row['uid']; 
											$name = $row['uname'];

											$_SESSION['email'] = $row['uemail'];

											$_SESSION['name'] = $row['uname'];
											$_SESSION['pwd'] = $row['upwd'];

											if(isset($_GET['referer'])) {

													$checkr = $conn->query("select * from referals where join_id='$put'");

													if($checkr->num_rows>0) {
	
														
													}

													else {
															//do nothing
															$adder = base64_decode($_GET['referer']);
											
																
														$conn->query("insert into referals(add_id,join_id,join_name,join_balance) values('$adder','$put','$name','0')")or die($conn->error);


														$conn->query("insert into earnings(uid,earned,deposited) values('$adder','2500','0')")or die($conn->error);


														$get_prev_hfc = $conn->query("select * from user_logins where uid='$adder'");

		if($get_prev_hfc->num_rows>0) {
			while($tr=$get_prev_hfc->fetch_assoc()) {

						$hf = 1000;
					
						$new_hfc = $tr['hfsc'] + $hf;
						echo $new_hfc;

$update_hfc = $conn->query("update user_logins set hfsc='$new_hfc' where uid='$adder'")or die($conn->error);


					}	
				}

														}
												
	
											}
										

										}
									}

								
						break;

						case 'SignIn':
						// check if user details are correct and set session...

					$mail = $_GET['email'];
					$pwd =  $_GET['password'];

						$chkk = $conn->query("select * from user_logins where uemail='$mail' and upwd='$pwd'") or die($conn->error);

									if($chkk->num_rows>0) {
										while ($rows = $chkk->fetch_assoc()) {

											

											$_SESSION['uid'] = $rows['uid'];

												
											$_SESSION['email'] = $rows['uemail'];

											$_SESSION['name'] = $rows['uname'];

$_SESSION['pwd'] = $rows['upwd'];
										}
									}
									else {
										header('location:signin.php?incorrect=yes');
									}

								
						break;
					default:
						// do nothing...
						break;
				}

				echo $errmsg;
		}

		else {
			header('location:signin.php');
		}
		//echo $_SESSION['uid'];

if (isset($_GET['claimHfc'])) {
		// hfc is the full balance..

		$hfc = $_GET['claimHfc'];
		$uid = $_SESSION['uid'];



		//we need to get the prev balance and update the coins..

		$get_prev_hfc = $conn->query("select * from user_logins where uid='$uid'");

		if($get_prev_hfc->num_rows>0) {
			while($tr=$get_prev_hfc->fetch_assoc()) {

						
						$taps =  abs($tr['hfsc'] - $hfc);
						$new_hfc = $tr['hfsc'] + $taps;
					//	echo $new_hfc;

$update_hfc = $conn->query("update user_logins set hfsc='$new_hfc' where uid='$uid'");

	$update_hfc_seconnd = $conn->query("update referals set join_balance='$new_hfc' where join_id='$uid'");

					}	
				}

				
								


						
	
		
	}

if(isset( $_SESSION['uid'])) {


?>
<body>
	<style type="text/css">
		body {
			color: white;
		}
	</style>

	<div class="container">
		<div class="head">
			<name>Hajj Finance</name>
			<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMwAAADACAMAAAB/Pny7AAAAY1BMVEUslv////8hk/8Ajf8bkf/5/P8Ai//z+P/h7v8Qj//j8P9dqf/U5/8Ahv/v9v/r9P+31/+ey/+Zxv+p0P9GoP/G3/9/u/90tP8ymf+Lv/+w0/9Po/9Xpv/O4//c6//A3P9prv+/NhPCAAAJ1klEQVR4nOWda7erKAyGNUIV212tWi+9//9fObAvaitRQLwc5/1w1uy1ptanICEhiY67ITnTXp5S6tfif0z7bVPB+FH4OJzjyynJi6J4vfg/eZJe4vPhEUb+RFATwByDw/lSva4OIczzmMcY4WL8P/hfhDjXV5We74+j/W+2DBMdnmm+L8VdAzhSAQjGcp+f4kNk99ttwgTxqbiWhCEUH0yMOdciiQOLN2ANJhAjAkQJpAYiwEcotcZjByZK+ZAANrF6eQDKa5HamW82YA555piANEBOmR8s3Mh4mPimObmkPARu8dIwx5OzG03yy7ODZORyPQaGhok1lG9xnHCMPTWHoUFSejZRuMArk8AcxxgmSEs1g6KNY75UG8JE8d72qDQ4+9hwpTaCoc/CmQjlG8cpnkZzzQQmrLIJUb5xyiqcB4YblolZhB01MTvaMHTSGdbCcQrtqaYLc5h6hjUipe4WRxMmsWokBwS7ZEKY8OXNhyLkvbTWAQ0Yer6ReVn4VLvdNZ4cdRh6KWdnEQ/ORZ1GGcY/OQuwiFXt5NuG8avpjQtCA5UqjSLMsVhkWH5ECkU/Rw0mei3IwmleajtPJZhwvygLp9krLdEqMOFtocelEdxUaBRggvnNS1fkpuCyDcOEyz4vfyIKm4FBmKhgS3P8iBWDq8AQzLGaeTuGy6uGVugBGJqsZFyEWDKwsxmASZey+zIBnMbAxGtiETT9vnQvTDCPh6wucHoX6D4YurTh74rs+x6bPph8dSycJjeDOa1sjv2obxHAYWaMw+gIMjxmg8Ici1WycBrcu8Fg6DonmRCcsEUAg7mvc5IJQXbXg1nUTR4S6kbLYehlteMiBEj4SQ4TrneSCUEm922kMLRa0V5ZJmT/LIUJVs7CHxvpHk0Kswanv1/kpgpz/lr6Xof1dVaEWffT/yPI1GDi1Xj9ffIkfloXhi4f8lMR3LoLWhdm3faykcSF7sDQ/b8C8+oMTQcmLpe+S1WVnaHpwKzVjekKiiGYFW/9P9V1BT5hkiVZgJEyK4mnuAGBzzSBD5hgwZA/wD4WjsoxVjQO5BX0wiz4+ENZu8M0LZVwPpeAdxh/uVAZvN3ZU+nRJbnfA3O4LvXIwMevfFL60PU97PQOEy81MEA+ZkyoZLs/PvUGc8wX8sqAXNwPJSqfY/lbaOMN5rGQkQGSfrK450zlg9kDhXkuMzDA0u4OWC2mwp4YjL9QHMOThSgjNZi3yEYbJrou8vx70lCL2pQn1/YRdBvmvsjAQCUNGymab2gvzm2Y0xL+MuTyBKxKbS3y2sc1LRi6xL4MY1E136SdMNyC8dU2RFaFxcD9XPFeoGz9GC2YYDftjUvkISkkfqJ8zr1r7ZxbMJfZYRiSFEfVWZxda+/Qgpk944chiUr0pJF/wFrOcwtm7kfG+/St/qSV4wKlFGbmCDPbP7oc39NdL8flSwYTzAvDrsgR+FPz0f1qxtcxvsg4wQ1j0f1Nd81es4FJ5rT/cEVOjM/al2LNHqCBmXMxg0x2vCJY9Fch0ixnDcyMjhlkTxmJ8Mj0b6J1iNbAaAaZRO8F0XfBQOAg43I3Ok1p1uYaxte6AIFXcrlckr1BqiAAMi4Hw5MhvwMT6VyI7ONQXMIPLtoOXScQ86eH4bkw1HuiGibQgCFFY+90A7ooS2R6xg21oalhNNzM9+RvmusYKElQ6Ud+ZupNkfqXrWHOytfqrKsXdTsHrBtU+pF5DRipb6eGuSiPDHTSJA+qywAQLCkxM7dyrB7rGiZV/mXK7kQJFZ3czonKr0bl6TYRxBrmpHq5jyjij/xcyQVB8t/HZbc1o20CI3MP/WR4I4IEldyjqsOvDJOMg3FpPLQVYUgg5jiy0HAcDLLhvfdPfA9h8asxJHIY5WnmONjqGuY9XoSHBJXo6ALQUTCAFuofE9TieAVSZZWMLgSRwKgvzeAgRlw010BK7LFAjPrs7oHpLs3qRrNzlNjWQVoB7e2RQIyN8LbEaKpvZ8RBAk4Tvbq/ClozmtoIoki2Mw+d8SYl4pK4MquBBi8uVsIOko2mjgsgOt2kaHkBPb3bT4KxWCoCg3rYzZwzsf3N8SLQZ9tjwwIxNLYUQpU4Z3pusyMWqJ5loHlwSImxWIugdN1m3YAGv00sxuIK+/nblQpjMQrEyCUJaBiEmqBM0R4Kx9N3Ozo8EGPtMFgaajIIAoKDV+jyR4I5AAiLxfQJaRDQKDwLPbXg99vOQSZiaPH4RBqeNQucS121XwUFsu852myUIg2cGx5pEIYvA4go2DzWlh5pmB42wQ4taEPGxW4zHulhk/kx4JdqK5VvqWWSKQs5BjQ/02Av/MHpsLzsnjYgB7Qjjs7JVbWJX2Q7CRw5Oh+T1AClWkelaFwgRiJPntQwKt0Eykqha8/IoJL0e+XpJuMSgcAZ7qVCc+udH7BEoLE+LAz28JsgaxpL0RqdPAeARjp+WCY4AkaT58anNe6qHpZqgkQDPK3RQsKp90LtZzJF0gSecGojFRgL3FCNiKmG8FRgK14Gy2KJ/aTpJF1f+pK0raTPy+ynag2JrvrS5+0UNnD/88N+cq9zmlzWvsIGSyUnQN43nhYDMR9f1FtyYqsYCK5t3/85VY5hfzGQtTItcBrLPM2zL9RfpmWvgO6vGs6Pr5N14hoqoLNY2vhdp5iRCVPyhkobt1V0uqly4H+pULsT49p2Cf2mmhtsq+3EphqCbKtVy7aa6GyqvZEbrB9GvfHUqtrnyqTTEmxTzdq21UbPPa6xVeufNBscrtoV0G49KcoLVyvtpqCuv1bHBgr0WOv/0Uh3Wy2Ot9V8elttwTfVsN11n2trpd+fp/NvveQAS9xXg1nV/nns6yc29WKQbb2yZVsv09nWa4629QKqbb0abFsvbdvW6/S29aLD5V5BSSZ4BeW2Xg7qiuT+2TcD7Hae5LWtXGEx9wt1sepOCzCbetWxO2vMpi8OYwdmU68Hdzf14nausJp6rkFWaT35I2Bc+px0rvEZplonYQGG7zzjvTcRDnj7WG1faQuGu2xpySbAAa9MFdwwyzAuDZLS9uhwlCQwmmEjYThOmDhWjagHSWiOMg7GFYWy1nCAo+jUrtmHcb/NDhnNwy9hYlisw/AtTp45Y+wo/2yW625dZLIBw1fqtLiWYALEP1Rei9RwLf6QHRhXLNX5vtSccPx/L/e5+VL8KWswXEF84gNE1MwPMOZciyS2RuLaheGKDk8xQp7HCDbpAAjzPD4ip/hgZ3bVsgwjdHzcz2lV3Eoi7pp5okOlaFTpsW9G/ohU6fn+GLkMyzQBjBD1o/BxOMeXNMmLoni9+D95kl7i8+ERRv4Yy9ijiWD+RCn1a/E/pv22iWHm1X/K2ZED0ul5tAAAAABJRU5ErkJggg==" width='17px'>

						

		</div>


<br>
	<?php
		echo $_SESSION['name']; 

?>
<br><br>
<div class="btns">
	<a href="deposit.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>">	<button>Deposit <i class="fa fa-credit-card" style="font-size:13px"></i></button></a>


	<a href="withdraw.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>">
		<button style="margin-left: 5%;">Withdraw <i class="fa fa-bank" style="font-size:13px"></i></button>

	</a>

</div><br>

<style type="text/css">
	a {
		text-decoration: none;
		color: white;
	}
	.btns button {
		border: hidden;
		border-radius: 3px;
		background: cornflowerblue;
		padding: 2%;
		width:30%;
	}
</style>
		<div class="section-two">
			
			<div class="name"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA8FBMVEX///8AKH1UWqhZWVkAAHIAIXpUXZbb2+UAJ31QUFAAEXamqsgAGnpRV6eFia0AAG1TU1P19fUAHXlBQUHl5u4AFXeIiIhpaWmbo7/r7vXJycmxsbFOVKY1RolJSUlLS0tfX1/m5uZDSqI8PDyhoaHv7+/T09PFxcVubm4+RaC9v9m1t9R+gbopTJJIT6Nrb7KPj497e3u3t7fS0+aLj8Fyd7U1PJyipcuusdJbYasTNIMdPYnc3NzU1OR0e6XBxNRcZJZ/hKsnMJlJVY+WnL8AOYuFib5lcKA3Q4eVmsS2uc3Y2ep3e7bGx9+nqs0wMDDJsSsbAAALqklEQVR4nO2cC1viOBeAoYAUxgrlOmgXSgGlikWUi+Cgzuo4C8rs//83X9JrAq0UaE33e8777M7UUkLeJjknKXFiMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADkTc832lfd/41aRr+77z/S7IeoSFeHlAS4j30W/G98vD3n8f9Wa8Xx1awuUkiHqExjB9eBnp3uFlhIU4KgVRTLof1cEoTvcOojQlLZqKNS0gQaSoBtIZAiZAwVjsTgmwsIAQtTn6c/74/Pz45H1V5+T56Pd3H8VdjaPWUUUV58GfuUIqVUg+e131lCsXUoVswUcfXEgRU+wv0B/fknGd7E/3i0o5Hr/Mp2Y+aj8dBVrBQ3nj8J9x3jDkc+6N9PPYeD2eW24vsjReBFrFw5iMcWBI5+KfG1h3IJ569lHo5d8HTgADZP73Ff4rnbQMs99cr7NfTx35KXakRCVniJoxZII2rI37wVXyID7GRvIK2jA2UaMxC79UzHoEbigKkZjbiKpgHgVuGLtXopAy3lQr5AVvGBOUg9ebBzNXp9ZhCIZ/NC6ISh5EX7myDkMwjI21q+0XhcpKUezjMAyHknp4JQ9C0JyAHoZhWmHciCtFc+J5GIaxqTDdflGITKUP54dQDP9oTMPpXNGIj09n9zUU08urbwZXS/pxXUkVPmLs6EkKsdJLJ2f7GHa+v2Rz2TImW0A3KfdCTWSmQpCPR3akpgnks03US2c7G3Z+58opY1XF87PrePx6VsiSigtJ+xNO9X1wr1GBDo9DQ/H4tVbapJbdNFyWC9bJOBKcYctZ4TdR6kpjGGum9MwYG/IzvT3KOTfiG4aPSd4RRM1nKPI5otSayqmsumlNFRTyZz2W8rP4dizDI7tV9S6qNyCPVKmnIArHLCVe0cPQyhY+FE3D31niHJK7NjoqCjZko/UEidU3GeijqRWqaeijFQ3D70nyHNJ7wK2Ij8leGptInBBjg8bRydjK+NsVdcNSjjjDPzzwuiL+IXtCFnulcYwWwu8KRz8qcuY02xR1w+cCcQYbmsMwnv2L+pw0s4GI7q1EBTnHMD7jN7XWDImreXR99leqzM9+lZPJ3E/6eXFJ4aThl5pZvEkcvTwl6rylFbHho9OEs4fr70/z9/c5ZuM71hoah2weuk2FtVRMGn4+FrGh08z8rxOPj9BBhhyTlb4orN9awrBQLqeOy+uQhs7F/PHr55+EBJlMTUuat2Hq93cXvh0ThkszF/J86p8tn4QMlQD2B+wMCnEC/axvp/Xha9nszQ+/tn1NM0WG84BqvQurwwxPCobg9Sy1LdnhXsriS5qrT3qpH0O9y+IEWNgyxkRseB9UtXfgHhl6xVK/hnqe32ZYEzhOYrFERNNF7mDD2fVDapthCX2QxOIrGmwoULOPPXopXhPOthiikMbOUPOYl/o2jOOnFlsM71gaKu/kmb0M+fjDFsN7idE4RJFmbc6/XxvyqS2GC4lRLEXZgpOo7RJ7Gm6LNH2BUT7Ew4NOF/sZxvm/KF4e12ZoKp61sdhXi5ZtHDcmz+xpGE/RFHLUTByHUjbzUn1Ro5H3dl/DDZLkTBWPBjZrCzxdpKN4YIb8jHjTm8AxWh/qEYCamQZmGM85MwkRNyGjNT6O4tTj6AANnWGHA9pazP4yLrW1SX9wvZR4XjqUWC2e9C8U6HwRmCGx6hexIKvnpXjtTcXx4GKps8tY7yiMAo3xOJF8lBlQPjzOEdukcTjjpLewVTww7q+zIbuU5TcbgcRjTvNyRPL8k+iSaTwSWA1DNEbG+sc7KfGflFnnY/ddzrvPS/VuwrHb1a53Ic759Y8nYx93POexG39nw5LehIyyIcboppqTrJbJ7PFx1ktwd8OexLSTWqGcnDR2licn3zxrvKvhu7Je/pdjDBPfoc4xfPFlOBV2Kj4MjFDHqT6fSNt79eMzP4ZXRhOq7x6vfwkj/S773Q7ykrIMy+nthqKR7BnGGczKHCn+ZsYnxFczr4VthkaY4RTGv3VhDBVO9bW7bknsqLF7rJfhvXHzBFa7FCzujHpwip+kXCsTX35b35B6GBqpkOPYb/Q2sr7P0UJtTph9Zihyu5QbKmY45TQ/MX1O7qAxN4i5G46MQcg4kBoMzbpofh68U41otKKr4ZsRR9nmQhtzJHKqj+fStRwxEnld0c1wYZcZiV+zfNpFcUnt9MLhxsVwYpXIOlNYDDWrQj6+P3lN8jzVUTcN7RaMRh/FmHEPKfrI/K85ar/ULBVf64lDS5CLzq8CW7kLhRsf+ySXWSrcxF+oV8WR1SM4lcWjfA8undvu499VKB0lU44g/cSjxElWUQqrfbOu2LGBEzQfk5Cno1y2kOIRhRy14+tSEWxBNrv1PLGjDepcbz6GT235eISizOyZbEGxZ98oX/39a+k5iprgcy4p0rdiJdk9lJPYz9Y2+HAUBaW3+4OH0shpwEgKOjMtjptOueliN8facCxEXRApmo0g9KdCvz+d+HcsLZwOgLs5y990+pSJ8XhTGOEHG31OefP3/GbeU/H+KlswalGUZKUKSA01oLm4U6TJtm+N0hPJzBCmoqBGKg+uU5pyqAE5S5ETJGW6uPPKHuLdYqo48VNXlAQWW0l3YSFgu/7UjhtIUukPL9/pUVm7uxr2FUUiwouuqIwiMxf1ZEXYOZaapo6Ffm+4WCyGH31prGqatHHZ+iarqCJONhVNUUHCCF4v75NG2ZDuKx4Sn6FxUf8HBUlW0x0dBY2LyHreN6td2lFQpv+JAbjGvDd2CyabepI6Yv7Yd0/E+76qfS4paGp/h+ldBKndjyTFwxJlSqn/Jwr/xs6BiPM/PWWsaHqe0EFHKD+qH5O7/3Tr0Yjz1WTx1hv1+6OP3ttisppHf+4CAAAAAH45v7g9/WH9IDabzQ510EEHZuLDh877mj/Oz89/kCWJzqV0+RfnIdTbJ+JNq5HJZOqtC7M6/9aLMj5ot8yDarHe6hgvDor1fy2Ds3/rDUS9Vb2wCztr2eU454qo/Eaj1Q5R4jPEfCaRSOQTibrZGCL6uYgPugnzAP1dNa+u5BNF2xBdmM+jdybqNzHnXOaU/oBBwyg/cxauiCcVLDeoVFstu0roBO6KCWyIDpqNRL7tXE0a5ivtdhUZFH8459YMz9DL9W6lW2w1Y0wQi8hDP7Ir1s7rtWzie48PLhqJujWK1gwb58b1+Rvn3Jph1eod6533q2jKsl09k1OjzZBYVT9ABg3Lys2wU0Rt6ZyjDUV0mxphCmylI3flxlqca+k1bufz6L+KPh4H1ktuhs36Z20oMxyBBoNuF40TqguhSsm4exVRR5WxcMYOg26G+Jz3OGyjeJRJnDFcZjXlLhoqjTxxn1G3rItITEZhtSg2iwmnkdcjzeCmguJk3b4DLrFUxrE6k2mzc2wOZBzxG137DBqI9R/NOup6Moox542EHWY3skUCZ4uq4+RiKFaK+Jqu3AnT4nPOB3Wcr+yA00TVvLjIZG5jg3zmFlXaHoYbho1inXynmyEq7ybfqHarcngG2+lUUG3rdj+SUQxt5xvN2BmKNjd5IlKsj8ML8RynA3sYuxoi2nK3W2c4cYvpaatop2TkMUD/i7i/Dgb2bCfmGmlQKLWnPJ6GsXa3W70Nq/K+QCmhaA+U20xCrua7eqpDSTHhXOYWS9FbW8S5NUPzlTNkyCjnV9rnHbGDY7psn2viiY4+U5PxwYC42sXwJu9Y4fjavsBYDXYzuOiI4kWmyyrUiNVuplgv4mFIdCI8JW3gWg/WpsxuhqcZKuMn8hmM1azdPC4fJdYqo7XFKZ7244aqkxXA03HdBLdtsUm94BiipKK3HZoDyda5TMLEvKzTssonesKXIt4O8BJIvqFm/rdytarnx3N0UCVeuKlWE6JzkayHxwo62XTeaGBddlqR8RKrwjSQdjrhzjfEDsNkDwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPw/8j+wODSaUh6WCAAAAABJRU5ErkJggg==" width='25%' style='border-radius: 100%;'> HFCoins</div>
			<div class="pph">PER TAP<br>+0.5 HFC</div>
		</div>
<br><br>
		<div id="coins"  style="display:block; margin:auto;" class="coins"> 

			<h2 id='h'>	<span id="balance">

					<?php

					$mail = $_GET['email'];
					$pwd =  $_GET['password'];

					$chkk = $conn->query("select * from user_logins where uemail='$mail' and upwd='$pwd'") or die($conn->error);

									if($chkk->num_rows>0) {
										while ($rows = $chkk->fetch_assoc()) {
												
												echo $rows['hfsc'];


										}
									}
												?>
				</span>

				<span id='tap_function'style="color: #333333;"><?php
				$uid= $_SESSION['uid'];
				 $get_prev_hfc = $conn->query("select * from referals where add_id='$uid'");

		if($get_prev_hfc->num_rows>0) {
					echo 'active';
				}
				else {
					echo 'notactive';
				}
?></span>

	<span id='tap_function_support'style="color: #333333;"><?php
				$uid= $_SESSION['uid'];
				 $get_prev_hfc = $conn->query("select * from transactions where uid='$uid' and txn_type='deposit' and txn_status='approved'");

		if($get_prev_hfc->num_rows>0) {
					echo 'active';
				}
				else {
					echo 'notactive';
				}
?></span>
<style type="text/css">
	#tap_function_support {
		margin-top: -20%;
		position: absolute;
		color: #333333;

	}
	body {

	}
</style>

			<br>	<br>
			<input type="text" id='count' value="<?php

					$mail = $_GET['email'];
					$pwd =  $_GET['password'];

					$chkk = $conn->query("select * from user_logins where uemail='$mail' and upwd='$pwd'") or die($conn->error);

									if($chkk->num_rows>0) {
										while ($rows = $chkk->fetch_assoc()) {
												echo $rows['hfsc'];


												
												

										}
									}
												?> " disabled>

		</h2>
			</div><br><br>
		</div>
		<style type="text/css">
			#count {
				color: orange;
				position: absolute;
				border: hidden;
				font-size: 33px;
				margin-top: -38%;
				text-align: center;
				width: 270px;
				background: #333333;

			}
			#h {
				position: absolute;
				margin-top: -8%;
				margin-left:9%;
			}
			#balance {
				padding: 0;
				display: none;
			}
		</style>
		<div id='err'>
	Tapping not Available:<br>Refer a friend and deposit to activate.
</div>
<style type="text/css">
	#err {
		
		position: absolute;
		padding: 2%;
		border-radius: 7px;
		font-family: "Roboto",sans-serif;
		display: block;
margin: auto;		color: white;
		background: red;
		margin-top: -14%;
		margin-left: 10%;
		}
</style>

<script type="text/javascript">
document.getElementById('err').style.display='none';
	var old_bal = document.getElementById('balance').innerHTML;
		

	const price = old_bal;
	const formatted = Intl.NumberFormat(undefined, {
		style:"currency",
		currency:"INR",
	}).format(price);


	console.log(formatted);
	document.getElementById("count").value = formatted;







var tapping_available =document.getElementById('tap_function').innerHTML;

var tapping_available_support =document.getElementById('tap_function_support').innerHTML;

		console.log(tapping_available);

	function tap_active() {

	var old_bal = document.getElementById('balance').innerHTML;

	const price = old_bal;
	const formatted = Intl.NumberFormat(undefined, {
		style:"currency",
		currency:"INR",
	}).format(price);


	console.log(formatted);
	document.getElementById("count").value = formatted;


			var toAdd = 0.5;

			if(tapping_available == 'active' && tapping_available_support == 'active') {
				
				document.getElementById('err').style.display='none';
			

  if(old_bal==0) {
			 document.getElementById('balance').innerHTML=toAdd;

                    }

                    else {

                        document.getElementById('balance').innerHTML=parseFloat(parseFloat(old_bal)+toAdd);



                        document.getElementById("coin").style.width='67%';

                        function tap_animate() {
                        	document.getElementById("coin").style.width='65%';
                        }
                       
                        setTimeout(tap_animate, 500);


                       document.getElementById("point").style.marginTop='-15%';



                         function number_animate() {
                        	document.getElementById("point").style.marginTop='5%';
                        }
                       
                        setTimeout(number_animate, 1000);

                    	

                    }
                  } else {
                  	document.getElementById('err').style.display='block';
                  	document.getElementById('coin').style.opacity='0.3';
                  	$('#err').fadeOut(5000);
			
                  }
		//document.getElementById('balance').innerHTML = old_bal+0.5;

	}
</script>

		<div class="heavy-coin"><br>
			<img onclick='tap_active();' id='coin' src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQEBUSERAVEhAVFhUVEBUVFRcYEhYWFRcXFhcVFRYYHSggGB0lGxUVIjEiJSkrLi4wFx8zODMsNygtLisBCgoKDQ0NDg0NDjcZFRkrKys3LSsrKystNysrKysrKy0rKysrKysrLSsrKysrLS0rKysrLSsrKzctKysrKysrK//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAwIEBQYHCAH/xABFEAACAQICBQkEBwUGBwAAAAAAAQIDEQQhBRIxQVEGByJhcYGRobETMkJSIzNicoLB0RSSk+HwFURjotLxFiRDU3Ojs//EABUBAQEAAAAAAAAAAAAAAAAAAAAB/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEQMRAD8A4aAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMryf5PYnHVNShC9vfm8qcFxlLd2bTrXJ3m8wWE1ZV1+019q1k9RP7FP4u2V+xAcp0JyWxuMf0GHnKO+bWrSX45WXcszetF8zlSVnicXGHGNODm+zWk0l4M6xQw1RpZKlFbFZOVvurKPmXdPR8PivN/ad1+7sXgVGg4Tmv0RTynKpVf2qqT8IJGZochNDL+5a34azNvpwjHJJLqWRLKSirvYBqf/AAHoR7cDq/hrIs8TzUaCq3UXOjJ/LWs12RqX9DfoxKoqMrrJ22rbbtCuQaV5g3nLCY5NfDCtDP8AiQdn+6jnXKPm90pgLuthZSpr/qUvpKfe45x/EkepFg4LON4PjBuPksn3lb9vHeqq4O0Z+K6L8EQeLwek+VvN/o3SDk/ZPC4pq+tBarfXKn7s+1Z9Zw/lbyMxejZfSxU6LdoVoXdN8E98X1PuuBrgAAAAAAAAAAAAAAAAAAAAAbhyH5EVMc1Vq3p4VPOXx1OMYX85ep85v+SLx1T2lVNYWm+lxqS26kX4Xf6nb9H4FTSjGKhQglGKirJpZasbbIrzAi0Ro6MKapYaEaVGO9Lo332+aXFszmFwkafurN7ZPOT7WTQgkrJJJbFsSK4WayeT2NfkVFNOV3ZJtK6b3XW1LeyqUpXtFJtK7u7bdiIHTlZR1Jay91qVo33SeflZ79pdOgpWbupWs3GUo92T2AUOabhLYm2s+tbPFFGIt0tbW1stRJSd11JZPff/AGL6nTSSSVkti3ImjED5DZd8Cxw83F5Lp1FrRT4uUs31KNmzKRRWokVZYR6lOUm2+lLN5t2erl1tp5dZf08klKV5W32TfHJFH7LG0UlaMWmorZlsy7c+4gxWGb15SgpydoUlZtRT3t26OebfUswLrE4SFWOrON1u4p8U9qZrGndEThCSkvb4dpqesk2o8Jx+Jda/mbHiK8oakIrXk10vmSVk5tb9+/aXUqkbqLebTaXFLb6rxA8wcuuQfsb4jBpyobZ09sqa+aPzQ815nPz1jym0C6d61CPR21KaWzjOC4cY95wfl7yVjSvicNFKi7e1hFZQb+KNvheWW70DRgAAAAAAAAAAAAAAADJ8ndDVMbiIUKeWtnOW6MF70n/W2xjDs3NfoP8AZsJ7eUfpq9rLfqX6Eeq7z70Bt+h9FU4Qhh6UdWjTSUuNuF/mltb/AJGywilaKsssl1LgiHA4b2cFHa9snxk9r/rgTys3q3cW10WvOz8MvUqI51Iu8ZZLZslftvayRNRhJN3k3Hrabb45JWXV/TRpuStNLJ7nk+1buwuEgPqQrVoU1eclHhfa+xEKqSqZU3aO+pbb/wCNb/vPLtLjDYOEHdK8t8nnN97AgWPb9yjUl1taq8x+1Yj/ALD8Y/kzJRRJFBWGlpScPfhKHW1ZeLVi6o6TT/nkZOKLLE6Hpyzh9HL7K6L7Y/pYguKOLi+p9f6l2jVqyqUbxms7Nx+WSW+L/IyWgataa1pWVL4Fndvis8lt7fUMhKlqylUinKTSWrlm1ss3s28bEHtfZLptzqzz1Y3ezdFborj+peQqKSvFprithBWpPN09WM5WUpNZ2W/ra3XAkhUUkmndPYc+5ZaDVGTqQinh6mU47oyltX3ZevajdaeIhDoJScU7Sna8dZu7u97u82lZX3FeNw8atOVOavCSakv63geR+VuhHhK7S+qneVJ9W+L61+hhDs/Lfk/KpTq0JK9Wk3Kk/maV4tfej69Rxlq3aB8AAAAAAAAAAAAAZPk1ox4rF0qKWUprX6oLOT8Ez0jozDLXSStCmlZbrvKPgr+KOQczGAU8RWrNfVwjGL65t38o+Z23RNP6PW3zbk+zZH/KkVF3u2X6v9y3hT1pWftFvTbdl1Z3S6msyZa92ktryk2nFLgo7b7erPbuJsNJtZ7m1e1r232AkiiqcIvoySaazTWT6iqKMXi8VOdRQp7di7d7fUgMzCJLFFGHptRSctZ2zeSu+xE8YkUiiSKCiVpAEitIJH0CLEYeFSOrOKlHgytK2SyW4+spbAx1VewnrL6qb6a3Rk/iXBP17S6xEXKPRlZ5OL3ZZq/FH2vTU4uL2NWZZ6OquzhL3o5PudvVegFFPCzaak9SndvUhJt5u76dk0r7ln17i7ZTXq6sXLck34Fm6dRR1vaSc7X1ctT7qVvPaBr/AC5wPuV4rNfR1OtPOD7ndfiPPHLnRv7PjJ2VoVPpIcM/eXjfxR6j0tQ9tQnDY5QerfdK14+DSOEc6OC1sPSrJZxlqy6lNN+sfMo5mACAAAAAAAAAAAOz80OG1NH1Km+c5v8Adjqo6xQpasVHgkvA55zY0baKo/ann31Ejo8qakmnse2zt6FRQ68Ftkr8FnLwWZcxRaU6MoSWSlFZKySkr22rY+1W7C/jEC2xlXUg3v3drI9B4W0faPbL3eqP83n4EWk7ytFbZSt52v5mapwSSSVkskupBR001Z5p7TFaRi6akoSaTtbO9r32X7DNRRidNrP938yDKYbCwp+6n1tttvtbIcfhYpa6upXV2m875Wa2F/Yt9IfVvtXqgMforDKqpTqXk9bVSu7JJLYl2kGPpuEtSE5JOSSzu0mlkm+8vdBfVy++/RFtpT61fej6IC7ei6fzVP4k/wBSGnhpU60bSlKm1Lbnqu2xv0uZGTII1bylH5beaAkbMbN6ta+6TSfev1RftmM0m7Z8NXyuBkJMsHWkk3GMVTjdW2O0dttyLuTLSVGEpNuOaave6i3udtkn1lE7kco5wcCpYLFR+RykvwTuvKx1OTNI5YUb0cZ9yT/9UX6hHm8AEUAAAAAAAAAAHoLmslraKo/Znn3VEzo0Ucr5k6/tNHVKe+FSX+ZXR1enmk+OZUVRiSxifIxJYoKxMo3rwXCcvVszUUYuvHVxEXxafitX8kZdIgJGH07t4ZR2d5m0jC6eWf7v5gXv9k0vmqfxqn+oixOjoQjrJ1LprbUm1t3puxk2W2P9x9q9UBaaD9yX336ItdLK9S3GUU7Np7FvWaLnQvuS++/RFvpJfSL70fRAXL0ZS+3/ABav+oowNB05TTbautVva1b8tncXsmRtgGzFaXll2v0RkpMw+Llr1ox4NX7uk/RIoykmRyYkyOTCPkmanyuyw2Ml/hy/+cUbTJmlc4+IVPReIk3Zz6K7ZysvIDzoACKAAAAAAAAAADqnMHpFRxVbDt/WQUorrg3e3c/I7zho9G3DL9PKx5M5HaYeCx1CunlGcdfrg3aXl6HrbDSUkpxd4zSafarryAliiSKEUSRQFhpai3BTW2Gf4d/hZPuL/D1FKKkt6K0jH4b6Cfsn9XLOk+HGH9fqBkJptNJ2e57beJjcTomVR3liJ9yhb0MmUtgQ0Kco+9Uc+F0l6IhxWGnO69tKKe5Rj6tF02UNgWGHwEqatGvK3XGD/Ijr6OlJ3ded92ULehkGyhsCKlGS96bl2pL0Ps5WEmRyZRBicbBRbUlLhZ7eBj9Fwbcqj7F27ZP0XiSYzAt+40k30k9izzlHr6tn53MIKMVFZJKyCKpMjkxJkbYFNSWRzHn0x3s8LQw6ec568l9mCa9WjqFKN31I87c7Gmv2vSVTVd6dK1KHDL3n4+gGmAAigAAAAAAAAAAHpLmN5TrGYL9mnK9fD5dbp36L7th5tM7yM5SVNG4yGJp3aWVSN/eg9qA9gKJWkWWidK0cXRhXoyUqc0mmn5PrL4AR4mhGpFxksn4p7mnuZIfGwLTFYqNGEU29llJ3ez5nxMfSx3TbT27U95l5pNWaTT2p7H2oxGK0OttKWr9l5x7ntj59gGRp4iMtjz4H1swLjXp7abkuMel6Z+RVHTKj7111SyfhKzAzLZRJmMWm6b631ZvyPv8AaE5e5Qn2z6C/zZlF82WdbFZ6tNKU9/yR+8/yWZQ6VWf1k7R+SndLvltfdYlhCMVaKSS2JbAimnHVWcnJ7W3vf5LqPkmfZMjkwPkmUNiTJaerCLqTajGKbbexJb2Br/OBp+OjsBUnde2mnCiuM5K1+48xzm5Ntu7bu3xbNu5zeVr0li24P/l6V40VfJ8Z99jTyKAAAAAAAAAAAAAAAA6JzUcv5aOqewrybwlR5/4cn8S6uJ6MwOkoTSaknGSThJbGmeLzfeQHODUwVqFdueGex7ZU+ziuoD1G2UNmqaD5UU5wjJTVSlJdGSzaNmpV4zWtGSa4oCtsobDZQ2AbI3ISZHJlH2UiKTEmRyYQkyOTEmRyYCTI5M+tn16sIudSSjGKu23kkuIFVCjfN7P68jj3O9zge1vgcJP6NZYia+Jr4IvhxKecnnQdVSwuBlansqVlk5dUOrrOSkUAAAAAAAAAAAAAAAAAAAAAZnk9ykxGClelNuD96m29R925nVeS/OJSqNatT2NXfCT6L7NzOIgD1fgeV0JWVWOr9qOcTN0MfSqK8KkZdjV/A8naM5T4vD5RquUfllmvPNGz4DnES+tpST4wf5OxR6ObI5M45gOcajuxUodU1+pmqHL6D/vdJ9tgjosmRSZoz5c0vixVJdjRZYnnHwcF0sVrdUI39AOhSkROouNzkmkOduirqjQnN7pTaUe212zTdN84OkMVde19lTfw01bxltA7Vyk5dYLAJqdRTq2ypwacu/gcX5Y8vsXpFuLfssPnalF5NfbfxGpyk27ttt7W9p8IoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//2Q==" width="65%">
		</div>


<br>


<script type="text/javascript">
	function claimHfc() {
		var hfc = document.getElementById('balance').innerHTML;

		window.location.href ='dashboard.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>&status_code=SignIn&claimHfc='+hfc;
	}
</script>
<br>
<point id='point'>

	+0.5
</point>

<style type="text/css">
	point {
position: absolute;
margin-top: 15%;
margin-left:45% ;
font-size: 15px;
	}
	.section-two {

	}
</style>
		<div class="pp"  style="margin-top:65%;" onclick="claimHfc()">Claim HFC</div>


		<div class="section-two" style="margin-top:10%;">
			
			<div class="name" > <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA8FBMVEX///8AKH1UWqhZWVkAAHIAIXpUXZbb2+UAJ31QUFAAEXamqsgAGnpRV6eFia0AAG1TU1P19fUAHXlBQUHl5u4AFXeIiIhpaWmbo7/r7vXJycmxsbFOVKY1RolJSUlLS0tfX1/m5uZDSqI8PDyhoaHv7+/T09PFxcVubm4+RaC9v9m1t9R+gbopTJJIT6Nrb7KPj497e3u3t7fS0+aLj8Fyd7U1PJyipcuusdJbYasTNIMdPYnc3NzU1OR0e6XBxNRcZJZ/hKsnMJlJVY+WnL8AOYuFib5lcKA3Q4eVmsS2uc3Y2ep3e7bGx9+nqs0wMDDJsSsbAAALqklEQVR4nO2cC1viOBeAoYAUxgrlOmgXSgGlikWUi+Cgzuo4C8rs//83X9JrAq0UaE33e8777M7UUkLeJjknKXFiMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADkTc832lfd/41aRr+77z/S7IeoSFeHlAS4j30W/G98vD3n8f9Wa8Xx1awuUkiHqExjB9eBnp3uFlhIU4KgVRTLof1cEoTvcOojQlLZqKNS0gQaSoBtIZAiZAwVjsTgmwsIAQtTn6c/74/Pz45H1V5+T56Pd3H8VdjaPWUUUV58GfuUIqVUg+e131lCsXUoVswUcfXEgRU+wv0B/fknGd7E/3i0o5Hr/Mp2Y+aj8dBVrBQ3nj8J9x3jDkc+6N9PPYeD2eW24vsjReBFrFw5iMcWBI5+KfG1h3IJ569lHo5d8HTgADZP73Ff4rnbQMs99cr7NfTx35KXakRCVniJoxZII2rI37wVXyID7GRvIK2jA2UaMxC79UzHoEbigKkZjbiKpgHgVuGLtXopAy3lQr5AVvGBOUg9ebBzNXp9ZhCIZ/NC6ISh5EX7myDkMwjI21q+0XhcpKUezjMAyHknp4JQ9C0JyAHoZhWmHciCtFc+J5GIaxqTDdflGITKUP54dQDP9oTMPpXNGIj09n9zUU08urbwZXS/pxXUkVPmLs6EkKsdJLJ2f7GHa+v2Rz2TImW0A3KfdCTWSmQpCPR3akpgnks03US2c7G3Z+58opY1XF87PrePx6VsiSigtJ+xNO9X1wr1GBDo9DQ/H4tVbapJbdNFyWC9bJOBKcYctZ4TdR6kpjGGum9MwYG/IzvT3KOTfiG4aPSd4RRM1nKPI5otSayqmsumlNFRTyZz2W8rP4dizDI7tV9S6qNyCPVKmnIArHLCVe0cPQyhY+FE3D31niHJK7NjoqCjZko/UEidU3GeijqRWqaeijFQ3D70nyHNJ7wK2Ij8leGptInBBjg8bRydjK+NsVdcNSjjjDPzzwuiL+IXtCFnulcYwWwu8KRz8qcuY02xR1w+cCcQYbmsMwnv2L+pw0s4GI7q1EBTnHMD7jN7XWDImreXR99leqzM9+lZPJ3E/6eXFJ4aThl5pZvEkcvTwl6rylFbHho9OEs4fr70/z9/c5ZuM71hoah2weuk2FtVRMGn4+FrGh08z8rxOPj9BBhhyTlb4orN9awrBQLqeOy+uQhs7F/PHr55+EBJlMTUuat2Hq93cXvh0ThkszF/J86p8tn4QMlQD2B+wMCnEC/axvp/Xha9nszQ+/tn1NM0WG84BqvQurwwxPCobg9Sy1LdnhXsriS5qrT3qpH0O9y+IEWNgyxkRseB9UtXfgHhl6xVK/hnqe32ZYEzhOYrFERNNF7mDD2fVDapthCX2QxOIrGmwoULOPPXopXhPOthiikMbOUPOYl/o2jOOnFlsM71gaKu/kmb0M+fjDFsN7idE4RJFmbc6/XxvyqS2GC4lRLEXZgpOo7RJ7Gm6LNH2BUT7Ew4NOF/sZxvm/KF4e12ZoKp61sdhXi5ZtHDcmz+xpGE/RFHLUTByHUjbzUn1Ro5H3dl/DDZLkTBWPBjZrCzxdpKN4YIb8jHjTm8AxWh/qEYCamQZmGM85MwkRNyGjNT6O4tTj6AANnWGHA9pazP4yLrW1SX9wvZR4XjqUWC2e9C8U6HwRmCGx6hexIKvnpXjtTcXx4GKps8tY7yiMAo3xOJF8lBlQPjzOEdukcTjjpLewVTww7q+zIbuU5TcbgcRjTvNyRPL8k+iSaTwSWA1DNEbG+sc7KfGflFnnY/ddzrvPS/VuwrHb1a53Ic759Y8nYx93POexG39nw5LehIyyIcboppqTrJbJ7PFx1ktwd8OexLSTWqGcnDR2licn3zxrvKvhu7Je/pdjDBPfoc4xfPFlOBV2Kj4MjFDHqT6fSNt79eMzP4ZXRhOq7x6vfwkj/S773Q7ykrIMy+nthqKR7BnGGczKHCn+ZsYnxFczr4VthkaY4RTGv3VhDBVO9bW7bknsqLF7rJfhvXHzBFa7FCzujHpwip+kXCsTX35b35B6GBqpkOPYb/Q2sr7P0UJtTph9Zihyu5QbKmY45TQ/MX1O7qAxN4i5G46MQcg4kBoMzbpofh68U41otKKr4ZsRR9nmQhtzJHKqj+fStRwxEnld0c1wYZcZiV+zfNpFcUnt9MLhxsVwYpXIOlNYDDWrQj6+P3lN8jzVUTcN7RaMRh/FmHEPKfrI/K85ar/ULBVf64lDS5CLzq8CW7kLhRsf+ySXWSrcxF+oV8WR1SM4lcWjfA8undvu499VKB0lU44g/cSjxElWUQqrfbOu2LGBEzQfk5Cno1y2kOIRhRy14+tSEWxBNrv1PLGjDepcbz6GT235eISizOyZbEGxZ98oX/39a+k5iprgcy4p0rdiJdk9lJPYz9Y2+HAUBaW3+4OH0shpwEgKOjMtjptOueliN8facCxEXRApmo0g9KdCvz+d+HcsLZwOgLs5y990+pSJ8XhTGOEHG31OefP3/GbeU/H+KlswalGUZKUKSA01oLm4U6TJtm+N0hPJzBCmoqBGKg+uU5pyqAE5S5ETJGW6uPPKHuLdYqo48VNXlAQWW0l3YSFgu/7UjhtIUukPL9/pUVm7uxr2FUUiwouuqIwiMxf1ZEXYOZaapo6Ffm+4WCyGH31prGqatHHZ+iarqCJONhVNUUHCCF4v75NG2ZDuKx4Sn6FxUf8HBUlW0x0dBY2LyHreN6td2lFQpv+JAbjGvDd2CyabepI6Yv7Yd0/E+76qfS4paGp/h+ldBKndjyTFwxJlSqn/Jwr/xs6BiPM/PWWsaHqe0EFHKD+qH5O7/3Tr0Yjz1WTx1hv1+6OP3ttisppHf+4CAAAAAH45v7g9/WH9IDabzQ510EEHZuLDh877mj/Oz89/kCWJzqV0+RfnIdTbJ+JNq5HJZOqtC7M6/9aLMj5ot8yDarHe6hgvDor1fy2Ds3/rDUS9Vb2wCztr2eU454qo/Eaj1Q5R4jPEfCaRSOQTibrZGCL6uYgPugnzAP1dNa+u5BNF2xBdmM+jdybqNzHnXOaU/oBBwyg/cxauiCcVLDeoVFstu0roBO6KCWyIDpqNRL7tXE0a5ivtdhUZFH8459YMz9DL9W6lW2w1Y0wQi8hDP7Ir1s7rtWzie48PLhqJujWK1gwb58b1+Rvn3Jph1eod6533q2jKsl09k1OjzZBYVT9ABg3Lys2wU0Rt6ZyjDUV0mxphCmylI3flxlqca+k1bufz6L+KPh4H1ktuhs36Z20oMxyBBoNuF40TqguhSsm4exVRR5WxcMYOg26G+Jz3OGyjeJRJnDFcZjXlLhoqjTxxn1G3rItITEZhtSg2iwmnkdcjzeCmguJk3b4DLrFUxrE6k2mzc2wOZBzxG137DBqI9R/NOup6Moox542EHWY3skUCZ4uq4+RiKFaK+Jqu3AnT4nPOB3Wcr+yA00TVvLjIZG5jg3zmFlXaHoYbho1inXynmyEq7ybfqHarcngG2+lUUG3rdj+SUQxt5xvN2BmKNjd5IlKsj8ML8RynA3sYuxoi2nK3W2c4cYvpaatop2TkMUD/i7i/Dgb2bCfmGmlQKLWnPJ6GsXa3W70Nq/K+QCmhaA+U20xCrua7eqpDSTHhXOYWS9FbW8S5NUPzlTNkyCjnV9rnHbGDY7psn2viiY4+U5PxwYC42sXwJu9Y4fjavsBYDXYzuOiI4kWmyyrUiNVuplgv4mFIdCI8JW3gWg/WpsxuhqcZKuMn8hmM1azdPC4fJdYqo7XFKZ7244aqkxXA03HdBLdtsUm94BiipKK3HZoDyda5TMLEvKzTssonesKXIt4O8BJIvqFm/rdytarnx3N0UCVeuKlWE6JzkayHxwo62XTeaGBddlqR8RKrwjSQdjrhzjfEDsNkDwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPw/8j+wODSaUh6WCAAAAABJRU5ErkJggg==" width='15%' style='border-radius: 100%;'>Referral: <input class='soji' id='soji' value='hajjfinance.com.ng/signup.php?refid=<?php echo base64_encode($_SESSION['uid']);?>' disabled/></div>


			<script>
					function copyText() {
					
						 document.getElementById("ppc").innerHTML='copied';


					  // Get the text field
					  var copyText = document.getElementById("soji");

					  // Select the text field
					  copyText.select();
					  copyText.setSelectionRange(0, 99999); // For mobile devices

					  
					  navigator.clipboard.writeText(copyText.value);

					  
					  console.log("ref links: " + copyText.value);




					}
			</script>
			<div class="p" id="ppc" onclick="copyText()">Copy</div>
		</div><br><br>
	</div><br><br><br><br><br><br>


</body>

<style>
	#coin {
		position: absolute;
		transform: scale(0.9);
		margin-left: 16%;
	}
	.soji {
		font-size: 13px;
		margin-top: 11%;
		border: hidden;
		position: absolute;
		width: 100%;
		margin-left: -13%;
		background: #333333;
	}
	.heavy-coin img {
		border-radius: 100%;
		display: block;
		margin: auto;

		border: 2px solid orange;
		box-shadow: 6px 6px 7px orange;
	}
		.p {
			font-size: 12px;
		padding: 3%;
		
		border-radius: 20px;
		text-align: center;
		width: 42%;
		display: block;
		margin: auto;
background: cornflowerblue;
	}
	.pp {
		font-size: 12px;
		padding: 2%;
		
		border-radius: 20px;
		text-align: center;
		width: 40%;
		display: block;
		margin: auto;

  background-image: linear-gradient(to left, gray , orange);
	}
	.pph {
		font-size: 12px;
		padding: 2%;
		
		border-radius: 20px;
		text-align: center;
		width: 60%;
		float: right;

  background-image: linear-gradient(to left, gray , orange);
	}

	.name-second {
		font-size: 16px;
		
		margin-left: 36%;
		margin-top: 10%;

	}
	.name {
		font-size: 18px;
		

	}
	.name img {
		border: 2px solid orange;
		padding: 2%;
	}
	.section-two {
		column-count: 2;
		background: rgba(89,89,89, 0.3);
		padding: 3%;
		border-radius: 12px;
		border: 0.5px solid gray;
	}
	.head img {
		border-radius: 120%;
		margin-top: 8px;
		margin-left: 1%;
	}
	.head {
		background: rgba(89,89,89, 0.3);
		padding: 5%;
		width: 110%;
		margin-left: -5%;
	}
	name {
		font-size: 21px;
		float:left;
	}
	left {
		font-size: 21px;
		float:left;
	}
	body {
		background: #333333;
		height: 100%;
		
		font-family: "Roboto", sans-serif;
		color: white;
	}
	.navbar {
 display: block;
  margin-left: 10%;
  border-radius: 14px;
  background-color: #262626;
  overflow: hidden;
  position: fixed;
  bottom: 0;
  width: 80%;
}

/* Style the links inside the navigation bar */
.navbar a {
  float: left;
  display: block;
  color: orange;
  text-align: center;
  padding: 20px 20px;
  text-decoration: none;
  font-size: 17px;
}
1 {
	color: orange;
}
/* Change the color of links on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */

</style>


 <div class="navbar">
  <a href="dashboard.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>&status_code=SignIn" class="active"><i class="fa fa-home" style="font-size:33px"></i><br></a>
  <a href="task.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>&status_code=SignIn"><i class="fa fa-globe" style="font-size:33px"></i><br></a>
  <a href="profile.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>&status_code=SignIn"><i class="fa fa-cog" style="font-size:33px"></i></a>
  <a href="signin.php"><i class="fa fa-power-off" style="font-size:33px"></i></a>
</div> 



<?php
	}
	else {
		echo "<h1>Please Login again</h1>";
	}

?>