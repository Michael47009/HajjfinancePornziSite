<?php
	include 'config.php';
	include 'cdn.php';


if(isset($_GET['select'])) {

	

	$email = $_GET['mail'];
	$pwd = $_GET['pwd'];

	$uid = $_SESSION['uid'];
	$amount = $_GET['select'];
 



	$amount =  str_replace(',', '', $amount);

	$insert = $conn->query("insert into transactions(uid,txn_type,txn_amount,txn_status) values('$uid','deposit','$amount','processing')") or die($conn->error);

		if($insert) {
			header("location:task.php?email=$email&password=$pwd&deposit_req=active");
		}


}




?>

<div class="phase-two">
<br><br>
<marquee>Secured Payment method</marquee><br><br>
	<div class="payment-process-panel">
		<red>Payment Method</red><br>
		<br>
			<div class="holdings">


				



					<div class="card" onclick="alert('This Payment method is not yet available');">
						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXIAAACICAMAAADNhJDwAAABF1BMVEX////rABv3nhsUNMv/XwDqAADn6ekLMMr3mABAU9Hr7voALMv/XgAAG8j3mgAAIMgAJskAJMnV2vX3nRjrABMAGcgHLsr29/3rABeDj9/2oRzQ1fPZ3vb+8eIAFMfm6fnrAAv5kBapsej8fA/6zM/83eD96tP4q0L+7/H84cH/+/X5umz4pjPFy/CUneLx8/y0u+snQs5GW9Nwfts1TND7zpm/xe7+aQb5Rwv95s7yfIP83Lb6x4z96ev1naP719rwX2nvR1P3Pg7yKhT9cgpictj6hRJRY9X5s1mYouTuOUb0kphtfNr4Rgz2qq/xaXH6wX19id7tLDnxdnzsGy73Wzf5vMBcbdgsRs/81qtOYNP3srb6vmfLs19hAAALV0lEQVR4nO2d+0PaShbHUWADxJAgAlIRvNxiffFSdGt91d1lrd5eu/Z21153//+/YyEkOWdm8hzCWNL5/mYeA35ycl4zJKmUlJSUlJSUVJL1l9f+Aj+fJHLhksiFSyIXLolcuCRy4ZLIhUsiFy6JXLgkcuGSyIVLIhcuiVy4JHLhksiFSyIXLolcuOJAvte5eWuqsxftxO3d86l2tw9i+BZLozmR3zx+eMhiff3j+iYE+O2Ly0/lHKh4dHh6/pOAnwP51ePHlWx2Z2NzBbS5sZPNbt5ed3zOO7g4fFPMFcvlVaRycbLp3eku/9dZGvEi33u8neDGtDH3bPbh2sPW9w+nuFddVS7mji63uf+XJREf8s6HbHbDFbetCfUvN8x5B6dvckV33ED90/68/9SPLR7knY8T5+EL3NRO9vYtcd7Bpad9E9RzR4mGHh353pfsTjBvy9Q/Iqd+WvQ3cAz93XmM/+MPpsjIr3eyIYHPLP0367z9o1xI4DPoh4nNXyIiv3oI41KQNrPfpi794DAXwqVgFYsXC/mHX1/RkD8GBE03bUwMfbcc1qcQhr6g//mVFQn5lyg+BZT9d1QTtwz9KJEJYwTkew98xFfer2Vyb3iYl4tJTF3CI79aCZuo0MQzmbW1X/iY5/5c4P/+SgqNvLMT3Y2bWstk+JmvJpB5WOQdjsAJxOdhfrrQ//8VFBL51QYn8feZzLzMk2bn4ZDvfZuX+IR5hittmTBPWAwNh/yWM3L+LYO09lc+5OVisnLFUMg/cGaHf88QWvsHn2spHy2aglCFQf4fTuKbGUpr/+RjXnzFOrTQbfdOxuPxU6/dLcQyYgjke5vR2iqO3tPIM2u/cCFfzQX1W8ajPKuXXt/l0Do69MXcgk75Th7bfRrpeslQ1aqqGiVNH52c1dgRB8+eA7gpBPKPcThy251zupZiQF+xN6pUSlWFVLWkbrGHNuEwrT3d0NKdLeoxOrDWS2uqksZSVL3SpsarvVTQBzfXA3kGI4/NrSzWtdS69WHFIAmlFY3xBe0S7FZNkz3TnQ1GDw68L5Wo0UzpZ9SAdwbeXaKvCKtg5CuxuRWTOW+mGGYiutEbalUCkPqZPiYPHNUnc0sdmAHPQl5Pu0pvkeN1K+QHngR+y0Dk1/FkKw7yXzldy7tg4iaBZ52AXqH2NxAhvWFuOoYTDJtnQ1XdiSsKNeAzeY2VfOBXDEIeY+yc08zDFkTrx/hOrzTIvU+Asno32wQXQRlaRzVoDwUnPZPjtUrUAbpLfCUVhDxmI1+8mU80RhZKud6aAiy12S5k9+rYOirtRTxt3JOfVTeoAzSXiB0NebyefC4zDz0DXasCMaNO7GqDh7ZNGsVTO/aNKY7TVMSDKHM7BMfPAOT/5TTyDU/i/Gb+KSzy1AnyHqQjQMGzdM8cbPHcIiKiqqnD0WhoVPRpxqiSKdCACbL2ncKN/IGzneWSkzvIM3zIV3OhWy0IhJLGOxqIUKXPXAV1tgk7pqpR3+pP3HOt3xicDHVjRH5SnvFACnVEVOQdTiO3u+TuzDlL0GLoznkBkW1is0TB004faxrQmmUbtSYiPiKseuuETDrX0aHO3RPUFvBH/lvcwdNEvvjuFjI+In6iS2E75S4gt/J0VBql1RY7ONJnl1RS7wZ8OX/k3ziD5+9+yDMZPiuP4FnqgAKnGNjh2PnzPSqEBuaWHmyx80gPobtp6PqBrvJFfrUIvyLCsyBDxeEMFT0WXqKUsXJ4HHyP2bGR7p1kR2871yngMgUgf4w/XzGRLzxn6SMHDeGsAZ5XSdsVy9DxQXZhib1FyTfLds5VjmsGDB3w5XyRf4mvh0gg5+0nlkOvU8RFvBPOUNnipOstuB/sfBJZeVpx60XaOnMu7CQZh0tX8vf//sh5Xbl3HWRpkb0tmq5TvOCaUrOxDNg24j0uhJRm3bOCh+tq9NGFYnqNEZDvLcaVzzFTEXqyvwsknXJw4ObgcRvRSjXISihdSnvUk5DkT4eDIpYqeCMhfxtnp5xAzts1/1dY5Clw20479QUFSieRQ+mkk8FTHRZF/+5qt0+EXa87XiYg5voiX1D0FFLzw01vx09UeSrOdBlqcylVe2Mbgq+1S8u7uHTnKDMW92EkumEcAXlME/suyBdfDKHkWpmV8ciFQOsJXQc0m3HMVDjV5ph26eBJZiUU3C90wzgC8hgnPSnkvCnLauiUZQtYWjMRaBoTetq4jQglTH9IzjuYXFWqqhwBYnO+E/mZQcpPfshv4+9pzYd8NfwiohoY6owADp5PzmEoIdSR72il2Urempy2BRNwlueCD0DjR0XO20YMKPenzUQ+4hFK/tSdY6hqnfzbNvup0kwbcaZCnp7tmVozLuWh3WgllzDVofjHTz/kX+dfiOgl3sQ8PHIoxk0CLUhhUEaBmoZ007XeZJ1LE24EVEI1rRwf4qfmOxmXWOQNSDu0FFkbQcrXdfU21gDHFboZjmp5GM+5gnAf+U/GJRZ5DSrwaakJHsSZU04ReU2JjXlnI42CDiEWxtNtFw9XwX8yLrHIU2PH6CaVCrRDiOVBaP5Hc8vszkbkRJvT8sV9AjsGQPuSXT0TFvlSh09cgfdwixYv4EK2n3b3v21qWYzltyEJh95Bgc5hOJAvc5KIMwh1XHCteIiY6tXl7udxvmi1rNahDWPcN2zBgSW39adhkC9zKZTC3ewR8tkVtE7TYzUipTyyc6vKwf1dVbcF2zS/ybikFvwp94lJ1F5JEfN1Ph1XVMhayPse6xWR6XMiX+a21kQDl2oG8oupcG/Re16+hsaZXZl7t5Gx6GV0oZEvc/M2RXhqMPIqipK4jeizFL+FGouzjtV3z/Vz9nBD7+GSOkVhasiSIaYP8GpEO6iesV4YuZ/ZFTujm7us/CbjEjoRZ+qJdebE6nCX1YipcTM/INONe+S4Zw7jjm0FMJ/jMxmX0OlmU+yCQdLHfmZWI6ZSVUXRq8/tdcv/FAZEf8uMno2g4Jn2TYASuqhiphbDhkzeRmgSztpUmPp/pVrS9GH+5e54qOnYOc16LMz6ZhdVXziRL+3SIUu0MyeDZAH5aLuQh0xdUapVhTq/MjVynMBUNVJoFoQT+dIukLNUp5w52W7CbUQ7qvpasGG6JbREvTpurGM14L7RvSfjkrkM1NIZ5VnIPja7GtE/Mqoj83TkjpgVnxCwXRqT4ZAv6WJnWwXSyqmW+LPLPJHqnXEbeTOTQatc2FYYmoL2XsySyCX9jsgV91R/FvdJrE0NctUQktK0MnfU72XnOOF8n8UsifzhiqMeds0UBbwa0c4vmBUsNnA9bSXaRCnK/JIZ1bOa55dK4s+zQF2MUCPdq8tqxFT3uFJifIuiVkZO3O1BvlJ16YpDLGCvh60k/ggRVDNURwbV93jSnV1NCIOt9nhoaCVDnaaI1emzEoxRHaYya2kYUXNpF9adQZnf+jsK/Klt3Ga+8J/aEiogUdMGfbSL3NPaaveeno/z+bvPdfqJIAXPs0zVPD8OlLQflC+BEvXYhOXQsjwcJFKn/MdWmEfgcDIX+QicZVJCHvS0TFqex5n9ub+fjIdULs9D+y62/3e5WBaCJB9NKVwhn3krH8Aan+RjhoVLPkxbuOQj44VL0IsRMvLFCI7k6z+ES8xLbsK8Go6VfMlNSr7KKRbJF5YJl3wtn3DJl08Kl3zFqnDJFwkLl3xdtnDN/VL4LM9L4Y/kS+G51Xn88DCBDPr6x/WNh31jbV9cfnqTAxWPDk/PE5ujkJoTuam9zs3bqW46IWBjbe/unk+0u/2TwJ4pDuRSkSSRC5dELlwSuXBJ5MIlkQuXRC5cErlwSeTCJZELl0QuXBK5cEnkwiWRC5dELlwSuZSUlJSUlJSUGP0fph16dFGTPc4AAAAASUVORK5CYII=" width='110%' height='40px'>
					</div>

					
					<div class="card">
						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA8FBMVEX///8noXwAAAD9//8konz//f8pn3wclnO34tgloXv6/////f78/PzB5N+42tIhl3YPnHPP5+Pi4uL0///c3Nzs7Ox6vKcblG/c9fTn+/bFxcVPT0/T09N5eXlCQkKkpKTr6+s1NTW7u7udnZ2Hh4coKCgvLy/u//+Cuqx+fn5YWFhjY2OVlZVJSUlAQECwsLDP8+pcr5U3m31qtaCi1MVTqo6cz8FgYGBycnIXFxchISGw3dJiq5RsrZmMx7UulHZJqouTwrRHnIDG8Omg0MWb38/Z/vWQ0LxYsZKBw61To4257N7O+O2gyr/k8e9wwaZ4gE3lAAAUeUlEQVR4nO1dC0ObStPmuoSFCBENQT2ttbb0VK0JSaw2aWJT277a97X//998M7uQK+RiFpJzvsw5VSGE3Ye57MzuzCJJO9rRjna0ox3taEc72tGOdvRPIRX+WRMkqeqmOyWUAI4KlKCTrE13SDRZum5ZgJDGhGj/ZSinWPfvElAkxjzVjoExjqLUbrZTQgkw6ZyLeCDZTCn/VQhRPFXqhWEYBGHoeR79Z8JjTOK84XaEn6BeUO60etXu04BTu/u12muV6wFFmNzG2kMGby8BKN3i4qdboHWSDue8n51eN3KI65pIMiNTNk3XNZz+oHlTCil+GSDCF3SVqvqmcWRTrFkAErqKrKC11h9iOA4xNU2eJUJkwOn3271SqDJjBMq63crJBzmVGxSv8q3tu4xpBP6bIcQMwAlBlOTPjxpzCQDjFvMQBwDUPJA0tfbrHuQSAAAKTTPTWKjJ/DMZWez60ddSiIzcZimN/RZgX6dhGCQRRaAUfMmHnJEy42XUq0lb7a2ieNpgN28csCqaNoZNk9OYGCOEfyisyG7Xb5S8rUQI1h5+UvhJa98I4pvUtywuatwCcWEFE2sCxqeOJzFR4DK/aWicmPUEY29LwbfIMLNkckny2yVq6aptMcOzHR4sDIO2Cp0KbwbGmvCQXL9bwaERbgzByDYgRPsHQ7X0e+Bzq7EmoaxWA0kHo7wlvp3K+lGroteiZerc8oSmx3VaHg6Qkr4NmmiBDnqtyMSxb30OguEhEdFko1EH5aZbgVAFC9P02fAgp7pnK0MENmqy29/z6FaoIUAsRQbAYz5Yxsi3Kka8i+k2AykOmjcGFJwYXfV+OSieQqCNo5RlJ/qOBgciFXUzwmpZVNLVoNknKKKCATIi/Q6aMcC4GSZa2O7Pe4PHCDkAhAfX74XgDm5s4AenqkxM5nyJl1KZe3VG1dNRVjYCENyqsiMTjQUQOSBkcqG5Xc8CH24jCKm352uOnJOIynL85Nx2QOlGAEpqx9DiAEGIuzZNGkepuU9B8WqIvigAlNcNJJZDanR/UhsaLHDMQAsu7fULwYcQnW7IxsTCWAlBjWSVRERKyxCMtqbT9VSq67QoJkIsL1UityiEqOpGleqSVVjMDxoRRGYeI2AmaX4PPJvCIg1VCrtuDsYzHRsfGDWzw52oYsh7dHMZH7Igsoiq/70IW4qzFbZFO07uEqpNHxL3PtBzn33DCW1QhjqLJopFqJmaW1X52laeC1TQhK2HTyRTRgU4cKniwcIXvyPxDID8/HDmVag9QxMyW7ESbHykblSDgVjNMx6GEZeq9T42mT4nwwKpNSkdIQ78mvnVY4uMuQEEIVUpyCiR0zrCF9G0tSlL/PETp+OxZdTcEIJzKD0YyVg/2xXDcBxjbcrUcEAZ/UR/IzeAiPA5MokWxzVTgmQaP36X1qcfGQ4vQ+g+enquno1Kq9nODPFrItoI/FQliB+jX5fynJdS1Yqf7Y8iQgGPdy5C0+3CgGGv30oGUanhZgxYxSA0NdMvqTmKqVr2M9AVxUNw3hpejghpgw0JGc0Xg1BzyzmO+GUjE55QhHOcP002u+H6jcwQZsnAjyaLKTZpadC5Mcqq+BkbHUIKm9aduXNPxSAkxGxSTItQxU5qqOiw9eZPPhWFUOvX4nQNgQhZykAQzQVYkB4CQqcnsQw4kQhBCanU8efHTIXwkLng/RBzNYT6pxbOOHfd+VPAxSBEPvoleOLiPfDaAhYWgpCliMnuH1AboQhBC6nUchcF9uh5rw9xrh7yJDiTBFQ0Ql3y2guWKZiNo1MQVQjncDSduiEYej2rh4ErL5ypxBkbS+SMFCC0fjoLWmUI1cnSH+wFBW9vauoI851m64TieprAZ3MFc9symqKnh8HQ7BkkNRN2RIgw7bsIafIUS+jKaiswFiM070NLErq6b0nqV4jt5zNRcx72Muh5GrUqPWdd+5AxjTHRlFvBpy4UIS7FLGpWMw03hXzXL8/esOynXQvkLDFX6bo3gFCsd1p3F641pXcM5wGdKYTojlSMLJlYAqHmNqlQlwYeVssli9di0pIWGMLK9P1UqexmZQ4vMW+uaVGoCo31VakKCM2XTtmn8FCqZK6wLtGKRty64NACRkPywrwEeDAzCEEPK8YaKwOAsCV2GUp9juTtQmj2xK5A0Qqa8K1C2PDE8nAPR0PBCF8OEM16PxSL8BtOBG8VQv+nWCltose2MkIswzNN15ge8RlCHPFHFXsrI3RLIgFK3n94h7Oa43jM4aoiIeidGCQaYDHl/1rTXptO1ee9TqvXq3bbg4gYPsA1ZXkYGOKiNhsXM3QVrnU7YhESklpjFyPkeZKYrW9itZ1r3DeqvU65EgQeTovNxBaq7rGSEYlXmNYq5daHZptwrjJ85vyscZAo8NtEiqlnzJnqJnK88qtpruE8VR/Kz4GnDtPPsZptCiHA1vVgrIgLazYA6d63BjCf3VCLf2YiFDxczJtZQGQsk910Sa8UeGPfqpQefj022oP+tOdteWqlT6L7RvPxplOujb5DvdpDw+cLXHP8U0RYFYhPQhdrzpoe46Mb/arjAjvmLXq1vZs/96hdBkSVpjltaTDLsOJqqLmyAZf55D+PD99jplI1LDf7DheMDJCIvyuUh+hEZiOEjvhPe5Sl9Hm1EhM1bijRYMA/YxqhirfUeOUeaq/JSoLvmw91kAFwqGm9FzlkHkKiPQldoMEHPm+Wtt/CEld4+L22OV61zetMZhBKLHqKeJYzXKHFdgVQRs1W3cOcmVrTyZbSGKFAiGV3TuikYfynq/jcDTepCSX8E4ZyNragKhP88bvwRA642nC6DxAaUa+a3ShK6YCKRFhyWS1SOhH/FwCsNwzCbcOUhdBMmfFwfLoJhoo0v5Q9EBTa/k1I9fA+O1SEKwfewm6vhjCbh6YTWl7LZ2X3RJsySVgDDF4bK9anakK6lejhTNe5xPafAkpvzKwKYvEI9+ZK6SDU1YY/HPonqi+YoY2llOXcWczQpPul8dCKQ75fkSSsBZiDUGhOdNmYI6Wy8R3G76pvsFypaRnFjgPCZHMhRljMlCalhET4v6b5gz2q02p2k+IR+kwA04mYbU/V1VrP8ZlpnHCmGQ9jW2rF22Zg0bBaTpFSlvUlO057D8yp9N3I9BQxDngSWn5Zx7WE7AfqNmsedNor9waO40ywkf1llnDDlpEa4nZKZWPajODjcZ2o0QrgQejebywLz0ZIukIRstWSLIAwrjuDDk8foLVSr3tPfIMNiqzMHjE+tRuNP81q9QOn6p9Gsz1aq0Ommya4P+3qQyWkuHGIGvR8LTuwQq+tKXSuzWNTf3NCOWLcdwIaFyaHte+tx2Y7cnzfj50bwiLFhGS2GwZWbbuYquc7GIv8qNdirw9cmsdofoAM3H4UG1vICxBiREiae7WxiXYvrNVLrZtetdltR1EfCSEjIgMPokEbHO9vN53f9VrILL+FhYY0rN+0DXfBUh4gFBw93WP0ND8TA56A0X/qdf4bTmW4gnvC90/6OaQgxL2UpldnIIAqtZpOHA3PJ01wBEyb8jxTw7wo7mS6vu80Hlu/60HIQoXUpQW2sjb+IcSG/+3cVAcQZyxZ048r3ULpgzlnuJhAigo31K1Wp1Sp1WreVDIhmFXd9rznZ4juS61fj80G6ixIZuz1LVjH5wjrYhcQ/7cUwlFEh54JYZNQhkOiQeyXSonTJkl6pX1/T3CGBqCh2U2i+njbngUtQbwW6kIRltyFCNkWLHGZQhwV4S8wmibE+HwXqcTxphTDFcYok0UgbBJkLAZdxEOi3XtikzGe3ReXkKTMl2Ldxlpz3kR2mzhhJxAhRjLiEK49qy/jYCGWh7T54qW1XBCaxm/BlTO05yxhSotDiFkRYlOFaXlRskmxCDGNVugSqS3Vou1C+AGDaaFM9BrbJKXEKCW7TwoisO69JZzFwhCapGZRoT6NzcP8rUHoNkQnJ9qq5C1OGSoMoea2JNE7LID70HthfXouUlpDERWaBQ0I6y9cls4DYZuyHevEAWR98gbbgtAkD5IqWkxxK4xfL2NiDjz0A2ZJhSYJQ8Bj1R0TF9JW3WlAKEKN7br1hxXsCt2Rl+0r4jVdkyzOUM4VIUv0ngnGBBBE5aDbJR+i2ZWZKBIhiBD8/yR0TSbukoWp3mEbc0BWrcUXykNAKDrPJCaLbZfaMl4QBwvWQ1mLxOZ7DQHimnI4mFNgWQRCFCH/Jo86YLbHM3SrZTJN2BhCuJk2CHKqIWU7F3tEW3lbE7G2FFgo5brnd8ddOYFPLEITtDDHTWositnQK4bCQhGabkeVcqx0tm2pMq9evQCE7TDXfTFwPr6aVUWQO0JcRzW+q5klYUIIhv1adhpmzghxeuYRfI9cdzPFMr3OEnVJ+SAkZBDoYufyZwlccK/LjekKOGcrSvRV87zZ43B+S5au0vw2/sCB37JorU/iHamXeOyYFKX1y1OlhiAK2TUzqQCxDt/9kPuOdGwzM93DbT2XHjNweXgm3KGYhLSqi+tGYf577rE99C2vSrIq1VIIPdlGdZL+VKuNldQQ1yONev4vMMHaT5S3sOEu67uNpe6Pk+ms6N+amt8pYItW3HMP1+CleuQusdaePP3ZooJ4Z96VAH7ApP/8EfIKXlsqOcsOi2xiZQoMifc9WwViNxRbFptOfLMNC7m4uDo/AcMQzm47t1oMZg4CauXpck8T2PsbnwdSOe8vGGdnRAHFNLYCNxIGa/PIpjRWjTRWRogtmNF3KrjudwFAyl4rU/Vz5yAijIjmlJJclcIgAkJLDZu4weCLMxiWRGgS0yhR/mbWwhBasUJ4Vd8kc7JARRDoOnCQv/SywPc/Je+69T4YeeshIdFvnMiUCrWk7IVauB2t5fX8nLfbNQd1/l5ENhgXu7++hbU9tIO6KPQVJXGVJsvgM91uTd3gW1nR4Hglw119AF+AUOYITdNvhswT3tQ7StC62d7PhiETgeoYV7QhUONmM+KZEDZsg6MRProi38IyLCs2ojKrsNncO7yxLkRlr7npLNjJbTUi/MWlfjPg3hN7Ie1GEDImoqTqUq25csQ+DyEA7Ds/eG3CJl9Lxj0b3OgKwv7OS9NtUhGa/WadTYyyh7hJhMkgDJoSVB1zVJq38pbmyWvNCKtXHHQ8tl9Wkd72YvLKDZ+/GXbRnnkz6OKgn9ena67TC7YL2pC8TtvQ4hLJFVmoxRXvsuka1TqV8t3S+oWEKkk7kTu2ecSy8OKX6mJlXr9Z83DKctNoUonHG50nY27hdzaZputUaxs2LvOIOR8gXF6pyd6HuDTGuJLENO57NVYtjDv6bqOUsto8Pn4937SztsdPhYjvO4qqpQDUz1b567m3kY0Q4lCEaKOX433vDZJqH5nPe4+xdbg9IfvMdP1+s8M2x0AFxJePbyO+aVJVr/7Q7eP8NttsRpvYwWfEX8NwosdSsD3vb16a2HvgaVi++foU+XwzobgyLUaImw/J5KnXqePgrlubej/eiwk0yfPwVWk0rJU737522xFxXZ8RsJW0v364KVVwOxMIo3GpYEMv4nw5MYs/9OpULwyD5+fnSqVcqddrz0EYjr2vmb8dZzuHwLnEN2idqBUdJ16vh6m5OhaH/OMQMh6ysS3ZWzYpr1THYj6LzRKy92//4yxNErZySMmpGGwiwSqHaG0wjN/Rjna0ox3tSCzlmG22LWT/f8C46Q6sQfb+kA6nPkn+OPh4sNod4cfp6Ph0eB4ouekhb9Ke7sM+/7pAspUxmri3LSUg3ypvV7jhhaK8lg6U8+TEpXKCvw4/8zauWCP7SZPvruHo41gfzm4V5XJtWBMdenV1dXWnXCFNMvFAueZ/vIYuL02fldvXp/Dd2+TE38oRtnOsvLs6Pr56o3yx2b3vjo/ZofI3PIRP0PgX5Q38/HRy8PrjKk90SbpSZk7Z0hk2jvR6hRZPOQMOlL+SMxzhqfKKC8StcsY+P+afntwpB8l1J8lXjt+J1nv7lcJk0pZOj5DYwdGlcnFyhK0CDw/x9Cm/WLJP8Cju2AlccXI0VNQz3s8ZhEeJ2J4cn4wjhJvHMvkXuy4+J1gXE4SSdB4rwzV2idMhNviF/837cvCOH12wB/Fe2cfj5FbXvHOZCGPtHiE8US5mEJ6N2CkUIcrl3d9v315eoM2xX98qx68vr+H0a0W5u718+5fCNeqLcnz59u35FybENmjS3cXl9ONPkdI3I8mzxxAeKB8LQyhJF3Ej3Hie8cduw+EV+/iIPe7kodsKagsgvBhXmiyEYIEUtC0Xl4f88xEPi0T4XjmNW70dIRyNFoesW9eJ4rzBqwHhhAXORHj4Vyz27w8neFgswi/K+zdI7xibhggTW2qzboFWsotAPDnCiVtlIoRLD4H2P7MHtDmECZ1PInw9hvB6eNGXw5UQcjoFRJvk4b6NxH2ZGR6OpNTml0lzEA5H/FvWc3TH4pu8mbClR8mVhdjST/E4dPoJTegJ44M9zcMh8PPPdibCfeVLcuYTG9KVeDxiPBxHeJ54ToXw8FK5PTg8PD24YEwDl/Xo1J5BeKjcHZ3CVWeJLU1DKB0r5wenp3Cvc+UNHoP67aMeHtyyB3SgXOHR6cGlkliqfBF+4ggPEw27YyyF1pVXbLRIpPQKfyVuAXv4MOKnIjwY+dIHU8fclo5cbSlx53JEKP0da7t9+en9+/dXl7FEHX1+h0py8iVu8BWXz7PPcNGbW37yr88Td7oGQOzxHF6+govevzqPWbR//uYd0Cc+Hh5e4cE7aGo41ly/O407AQhXCtcWkz38MTqT5vpOn7NTTp9xv2fu99JPjX1yGY/LwmhkPqXEQtpjH9nJ0eiPtF/xgXK8z74/dofxy0a3mvq2bQ9/HdxdrQ9qFRrN0qQ/+cmzMFzenWV/PK8d/uPyThGvhuIInsbB+fFaHbz+eCk6dhJJ60eu2z/nhSq4Ri+5fm4/zB3taEc72tGOdrSjHe1oRzva0Y52tKMdjdH/AfYjvZevf3mQAAAAAElFTkSuQmCC"width='60%'>
					</div>
			</div>


<br>
<span><b>Account Number: </b><br><or>8115501712 <br>Opay<br>Transaction Desc: <b><?php echo base64_encode($_SESSION['uid']);?><br></or></span>
<br>



<div class="exp">
	<br>
<span><b>BNB Smart Chain (BEP20)</b></span><br>
<img src="./images/usdt.png" style='display: block; margin: auto;'width="70%">
</div><br>
			<or>0xf9af29ec68874ae1fa4bc856223443625bfc1995</or>


	<form method="get" action="deposit.php">
	<br>

	<select type='select' name="select"id="select" >

		<option>Select Amount Sent.</option>
		<option>2,500</option>
		<option>5,000</option>
		<option>7,500</option>
		<option>10,000</option>
		<option>15,000</option>
		<option>20,000</option>
		<option>30,000</option>
		<option>50,000</option>
		<option>70,000</option>
		<option>90,000</option>
		<option>100,000</option>
		<option>120,000</option>
		<option>150,000</option>
		<option>180,000</option>
		<option>200,000</option>
	</select><br>

<input type="text" value="<?php echo $_GET['email'];?>" name="mail">

<input type="text" value="<?php echo $_GET['password'];?>" name="pwd">
<button id="submit" onclick="dashboard();"> I have Made Payment</button>

</form><br><br>
	</div>
	<br><br><br><br><br><br><br><br><br><br><br><br><</div>

<style type="text/css">
#select {
	width: 90%;
	border: hidden;
	background: white;
	border: 1px solid #ccd;
	padding: 2%;
	display: block;
	margin: auto;
}
input[type='text'] {
	display: none;
}
	#submit {
			border: hidden;
			color: white;
			font-weight: bolder;
			width: 70%;
			padding: 3%;
			border-radius: 7px;
			display: block;
			margin: auto;
			background: orange;
	}
	or {
		color: cornflowerblue;
		font-size: 13px;
	}
	.holdings {
		column-count: 3;
	}
	.card {
		margin-top: 3%;
		border: 1px solid #ccc;
		background: white;
	}
	.card img {
		margin-left: 5%;
	}
	red {
		color: red;
	}
	.payment-process-panel {
			background: #e6e6e6;
			color: black;
			display: block;
			margin: auto;

			border-radius: 14px;
			padding: 4%;
			width: 95%;

	}
	marquee {
		color: orange;
	}
	.phase-two {
		background: #262626;
		height: 100%;
		padding: 4%;
		color: white;
	}
</style>



<style type="text/css">
	.phase-two {
		background: #1a1a1a;
	}
</style>