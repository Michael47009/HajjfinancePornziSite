<?php

	include 'config.php';
	include 'cdn.php';


if(isset($_GET['approve'])) {
	$user_to_approve = $_GET['approve'];
	$amount_add = $_GET['amt'];
	$trans_id = $_GET['txn_id'];

	//get user bal first


			$get_prev_hfc = $conn->query("select * from user_logins where uid='$user_to_approve'");

		if($get_prev_hfc->num_rows>0) {
			while($tr=$get_prev_hfc->fetch_assoc()) {

						
						//convert to hfcs
				$conversion = $amount_add/2.5;
						$new_hfc = $tr['hfsc'] + $conversion;
						echo $new_hfc;

	$update_hfc = $conn->query("update user_logins set hfsc='$new_hfc' where uid='$user_to_approve'");

	
					}	
				}
$update = $conn->query("update transactions set txn_status='approved' where uid='$user_to_approve' and txn_id='$trans_id'");

				





}
if(isset($_GET['decline'])) {
	$user_to_decline = $_GET['decline'];
	$trans_id = $_GET['txn_id'];

	$decline = $conn->query("update transactions set txn_status='declined' where uid='$user_to_decline' and txn_id='$trans_id'");
}
?>

<style type="text/css">
	h5 {
		margin-left: 5%;
	}
	h3 {
		background: #;
	}
	body {
		background: #333333;
		color: white;
	}
	.panel {
		background: gray;
		width: 80%;
		padding: 4%;
		display: block;
		margin: auto;
	}
	gr {
		color: green;

	}
	or {
		color: orange;
	}
</style>
<h4>
HAJJ FINANCE CONTROL PANEL
</h4><hr>
<h5>useful links:<br>
 <a href="admin.php"> > admin home page</a><br>
  <a href="profits.php">> profit adder</a><br>
   <a href="deposit_admin.php">> deposit request</a><br>


</h5>
<br>
<h4>
DEPOSIT CONTROL
</h4>


<style type="text/css">
	table {
		border: 1px solid white;
		border-radius: 7px;
	}
	tr {
		border: 1px solid white;
		padding: 1%;
	}
	td {
		border: 1px solid white;

		padding: 1%;
	}
	td button {
		border: hidden;
		background: red;
		padding: 5%;
		width: 50%;
		border-radius: 4px;

	}
	a {
		color: white;
	}
</style>
<br><br>
<table width="300%">

	<tr>
		<td width="15%">Full name</td>
		<td width="4%"> txn Type</td>
		
		
		<td width="10%">Txn Amount</td>
		
		<td width="10%">txn Status</td>
		<td width="10%">txn Date</td>
		<td width="10%">action</td>
	</tr>


<?php
	$gwt= $conn->query("select * from user_logins");
	if($gwt->num_rows>0) {
		while ($gwtt=$gwt->fetch_assoc()) {
			$ids = $gwtt['uid'];
			// code...

			$chkk = $conn->query("select * from transactions  where uid ='$ids' order by txn_date desc") ;
			if($chkk->num_rows>0) {
				while ($vbb=$chkk->fetch_assoc()) {

	
?>
	<tr>
		<td><?php $g = $vbb['uid'];

//get names not id
		$names = $conn->query("select * from user_logins where uid='$g' "); 
		while ($pr=$names->fetch_assoc()) {
			// code...
			echo $pr['uname'];
		}
	?></td>
		<td><?php echo $vbb['txn_type'];?></td>
		
		<td><?php echo $vbb['txn_amount'];?></td>
		<td><?php echo $vbb['txn_status'];?></td>
		<td><?php echo $vbb['txn_date'];
			
	?></td>
		<td>

			<?php
				if($vbb['txn_status'] == 'processing') {
			?>

<a href="deposit_admin.php?approve=<?php echo $vbb['uid'];?>&amt=<?php echo $vbb['txn_amount'];?>&txn_id=<?php echo $vbb['txn_id'];?>">


<button style="background:green;">Approve</button>
</a><br>

<a href="deposit_admin.php?decline=<?php echo $vbb['uid'];?>&txn_id=<?php echo $vbb['txn_id'];?>">


<button>Decline</button>
</a>
	<?php

}
else {
	echo $vbb['txn_status'];
}
	?>
				

			</td>
	</tr>
<?php

	}


}
}
	}
?>
</table>



















