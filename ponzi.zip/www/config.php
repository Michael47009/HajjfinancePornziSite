 <?php
 session_start();
		$servername = "localhost";
		$username = "michael44";
		$password = "victor47009A";
		$db = "michael44";
		// Create connection
		$conn = new mysqli($servername, $username, $password,$db);

		// Check connection
		if ($conn) {
		 // die("Connection failed: " . $conn->connect_error);
		}


		//echo "Connected successfully";
?> 