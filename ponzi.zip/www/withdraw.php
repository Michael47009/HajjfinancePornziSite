<?php

	include 'config.php';
	include 'cdn.php';



$uid = $_SESSION['uid'];


$email = $_GET['email'];
$password = $_GET['password'];

?>
<style type="text/css">
	body {
		background: #333333;
		color: white;
	}
	a {
		color: white;
		font-size: 27px;
		margin-left: 5%;
		word-spacing: 35px;
	}
	.header  {
		padding: 4%;
		font-size: 21px;
		word-spacing: 35px;
	}
	ins {
		font-size: 21px;
		
		color: orange;
	}
	p {
		text-align: center;
	}
	input {
		border: 1px solid #ccc;
		border-radius: 10px;
		padding: 3%;
		width: 90%;
		display: block;
		margin: auto;
		color: white;
		background: #333333;
	}
</style>
<body>
	<head class="header"><br>
	<h3><a href="task.php?email=<?php echo $_GET['email'];?>&password=<?php echo $_GET['password']; ?>&status_code=SignIn"><i class="fa fa-arrow-left" style="font-size:23px"></i></a>	Withdraw</h3>
	</head>

<p><ins>Bank</ins></p>


<br>
<marquee><h3>withdrawal Date: 1st January, 2025.</h3></marquee><br><br>
<code style="margin-left:5%; width:80%;">Available:<big>
	
<?php
$mail = $_GET['email'];
					$pwd =  $_GET['password'];

					$chkk = $conn->query("select * from user_logins where uemail='$mail' and upwd='$pwd'") or die($conn->error);

									if($chkk->num_rows>0) {
										while ($rows = $chkk->fetch_assoc()) {
												echo $rows['hfsc'];

echo ' ~ NGN<span id=fmt>'.$rows['hfsc']*2.5;
echo '</span>';
												
												

										}
									}
												?></big> 
													
<script type="text/javascript">
	var pricel = document.getElementById('fmt').innerHTML;
		

	const price = pricel;
	const formatted = Intl.NumberFormat(undefined, {
		style:"currency",
		currency:"USD",
	}).format(price);


	console.log(formatted);
	document.getElementById("fmt").innerHTML = formatted.replace('$','');


</script>
												</code><br><br><br>
<?php

		if(isset($_GET['sb_btn'])) {
				$bnk = $_GET['bank_name'];
				$aza = $_GET['bank_account'];
				$aza_name = $_GET['user_name'];
				$amt = $_GET['amt'];

$desc = "withdrawal to: $bnk($aza), $aza_name";

			$insert = $conn->query("insert into transactions(uid,txn_type,txn_amount,txn_status) values('$uid','$desc','$amt','processing')") or die($conn->error);

			if($insert) {
			header("location:task.php?email=$email&password=$password&w_req=active");
		}

		}

?>
<form method="get" action="<?php echo $_SERVER['PHP_SELF'];?>">
	

		<input type="text" name="bank_name" placeholder="Bank Name" value="<?php
                    $get_two = $conn->query("select * from user_logins where uid='$uid'");

                        if($get_two->num_rows>0) {
                            while($row_two=$get_two->fetch_assoc()){
                                echo $row_two['bnk'];
                            }
                        }
                        else {
                          //  echo 'Bank name not added yet.';
                        }

                    ?>
" required><br>

		<input type="text" name="bank_account" placeholder="Account Number" value="<?php
                    $get_two = $conn->query("select * from user_logins where uid='$uid'");

                        if($get_two->num_rows>0) {
                            while($row_two=$get_two->fetch_assoc()){
                                echo $row_two['bnk_no'];
                            }
                        }
                        else {
                          //  echo 'Bank name not added yet.';
                        }

                    ?>
" required><br>

		<input type="text" name="user_name" placeholder="Account Name: (First and last name)" value="<?php
                    $get_two = $conn->query("select * from user_logins where uid='$uid'");

                        if($get_two->num_rows>0) {
                            while($row_two=$get_two->fetch_assoc()){
                                echo $row_two['bnk_name'];
                            }
                        }
                        else {
                          //  echo 'Bank name not added yet.';
                        }

                    ?>
" required><br>

<input type="text" name="amt" placeholder=" amount" required><br>




		<br>
<input type="hidden" value="<?php echo $_GET['email'];?>" name="email" placeholder="Bank Name" required>


		<input type="hidden" value="<?php echo $_GET['password'];?>" name="password" placeholder="Bank Name" required>


		<input type="submit" name='sb_btn' style="background: cornflowerblue; width:60%; border:hidden; opacity: 0.5;" value="withdraw" disabled>
	</form>
</body>


<style type="text/css">
	marquee {
		color: cornflowerblue;
	}
</style>