
<?php

include 'config.php';
include 'cdn.php';

$uid = $_SESSION['uid'];
$emmail = $_SESSION['email'];
$name = $_SESSION['name'];
$password = $_GET['password'];

//echo $uid.$emmail;

?>
<body>
    <div class="profile-container">
        <div class="profile-header">
            <div id="uc"><?php  echo substr($name, 0,1); ?></div>

            <style type="text/css">
               #uc {
                background-color: gray;
                padding: 6px 14px;
                border-radius: 100%;
                margin-left: -4%;
                font-size: 21px;
                color: white;
                font-weight: bolder;
               } 
            </style>
            <h1 class="username" style="margin-left: 4%"><?php echo $name; ?></h1>
            <button class="edit-btn">Edit Profile</button>
        </div>
        <div class="profile-info">
           
        </div>
        <div class="profile-edit" style="display: none;">
 

            <h2>Edit Profile</h2>





















<br><br>
<?php

    if (isset($_GET['bnk_name'])) {
        // code...
        $bnk = $_GET['bnk_name'];
        $user_name = $_GET['aza_name'];
        $bnk_no = $_GET['bnk_no'];
 //echo $bnk.$user_name.$bnk_no;

        $put = $conn->query("update user_logins set bnk='$bnk' where uid='$uid'") or die($conn->error);

         $put = $conn->query("update user_logins set bnk_name='$user_name' where uid='$uid'") or die($conn->error);


 $put = $conn->query("update user_logins set bnk_no='$bnk_no' where uid='$uid'") or die($conn->error);


$chk = $conn->query("select * from task where uid='$uid' and task_name='aza'");

if($chk->num_rows>0) {
   
}
else {
    $conn->query("insert into task(uid,task_name,task_status)values('$uid','aza','done')");

    $get_prev_hfc = $conn->query("select * from user_logins where uid='$uid'");

        if($get_prev_hfc->num_rows>0) {
            while($tr=$get_prev_hfc->fetch_assoc()) {

                        $hf = 1000;
                    
                        $new_hfc = $tr['hfsc'] + $hf;
                       

$update_hfc = $conn->query("update user_logins set hfsc='$new_hfc' where uid='$uid'")or die($conn->error);

    }
}
    echo "<div class='success'>Account number added successfully, you earn +1000 Hfc.</div>";
}



    } 
    

?>
<style type="text/css">
    .success {
        position: absolute;
        padding: 4%;
        background-color: cornflowerblue;
        color: white;
        border-radius: 7px;
        display: block;
        margin: auto;
    }
</style>
<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">


                <div class="form-group">
                   
                    <input type="email" id="email" value="<?php echo $emmail; ?>" disabled>
                </div>
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" value="<?php echo $name; ?>" disabled>
                </div>
                <div class="form-group">
                    <label for="username">Bank name:</label>
                    <input type="text" name='bnk_name' id="username" value="<?php
                    $get = $conn->query("select * from user_logins where uid='$uid'");

                        if($get->num_rows>0) {
                            while($row=$get->fetch_assoc()){
                                echo $row['bnk'];
                            }
                        }
                        else {
                           // echo 'Bank name not added yet.';
                        }

                    ?>" required>
                </div>

                <div class="form-group">
                    <label for="username">Account name:</label>
                    <input type="text"  name='aza_name' id="username" value="<?php
                    $get_two = $conn->query("select * from user_logins where uid='$uid'");

                        if($get_two->num_rows>0) {
                            while($row_two=$get_two->fetch_assoc()){
                                echo $row_two['bnk_name'];
                            }
                        }
                        else {
                          //  echo 'Bank name not added yet.';
                        }

                    ?>
" required>
                  
                </div>

                <div class="form-group">
                    <label for="username">Account number:</label>
                    <input type="text"  name='bnk_no' id="usernasme" value="<?php
                    $get_three = $conn->query("select * from user_logins where uid='$uid'");

                        if($get_three->num_rows>0) {
                            while($row_three=$get_three->fetch_assoc()){


                                if($row_three['bnk_no']=='nil') {
                                    echo 'nil';
                                }
                                else {
                                 echo $row_three['bnk_no'];   
                                }
                            }
                        }
                        else {
                            echo 'Bank name not added yet.';
                        }

                    ?>
" required>
                </div>

<input type="hidden" name="password" value="<?php echo $_GET['password'];?>">
                <button name="update" class="save-btn">Save Changes</button>
            </form>
        </div>
        <div class="profile-buttons">
          
        </div>
    </div>

    <script>
        const editBtn = document.querySelector('.edit-btn');
        const profileEdit = document.querySelector('.profile-edit');

        editBtn.addEventListener('click', () => {
            profileEdit.style.display = profileEdit.style.display === 'block' ? 'none' : 'block';
        });
    </script>
</body>
</html>



<style>
body {
    font-family: 'Roboto', sans-serif;
    background-color: #333333;
}

.profile-container {
    width: 350px;
    margin: 50px auto;
    background-color: #fff;
    padding: 20px;
    border: 1px solid #ddd;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
}

.profile-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
}

.profile-picture {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    margin-right: 10px;
    object-fit: cover;
}

.username {
    font-weight: bold;
    font-size: 18px;
}

.edit-btn {
    background-color: #4CAF50;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
}

.edit-btn:hover {
    background-color: #3e8e41;
}

.profile-info {
    margin-bottom: 20px;
}

.bio {
    font-size: 14px;
    color: #666;
}

.stats {
    list-style: none;
    padding: 0;
    margin: 0;
}

.stats li {
    display: inline-block;
    margin-right: 20px;
}

.stats li span {
    font-weight: bold;
}

.profile-edit {
    background-color: #f7f7f7;
    padding: 20px;
    border: 1px solid #ddd;
    margin-bottom: 20px;
    border-radius: 10px;
}

.profile-edit h2 {
    margin-top: 0;
}

.form-group {
    margin-bottom: 10px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
}

.form-group input, .form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.save-btn {
    background-color: #4CAF50;
    border-radius: 4px;
    border: hidden;
    padding: 4%;
    width: #fff;
