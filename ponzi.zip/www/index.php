<!DOCTYPE html>

<html lang="en">

<head>

  <title>CASH APP</title>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link rel="preconnect" href="https://fonts.googleapis.com">

  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  

  

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

  

  <script>

    $(".scene-two").hide();
    $("#cover-spin").hide();

  $(document).ready(function(){
$(".pay-loader-scene").hide();

$(".payment-failed").hide();
$("#cover-spin").hide();

     $(".scene-two").hide();

        $('.first-one').hide();


        $('.footer').hide();

     $(".preloader").fadeOut(5000);



      $('.first-scene').fadeIn(4000);

            $('.footer').fadeIn(15000);

      

        $("#re").click(function(){

         

          $('.first-scene').hide();

            //alert('amint');

            

            var amount = document.getElementById('amt').innerHTML;

            var run = document.getElementById('dollars').innerHTML = '$'+amount;

            

            $(".scene-two").fadeIn("1000");

});     

                $("#cancel").click(function(){

                         $('.scene-two').hide();

                         $('.first-scene').fadeIn();

                }); 

                $(".pay-btn").click(function(){

                      
                   $(".pay-loader-scene").show();
                   $("#cover-spin").show();
                   $("#cover-spin").fadeOut(4000);
                   $(".scene-two").fadeOut();

$(".payment-failed").fadeIn(5000);
                   // $(".payment-failed").fadeIn(5000);
                }); 

                 $(".done").click(function(){

                    
$(".payment-failed").fadeOut();
                   $(".scene-two").fadeIn();
                }); 


 $(".done").click(function(){

                    
$("#cancell").fadeOut();
                   $(".scene-two").fadeIn();
                }); 


  });

  

  

  

  

  </script>

  

  

</head>

<div class="preloader">

    <div class="loading">

  <svg class="pl" width="240" height="240" viewBox="0 0 240 240">

    <circle class="pl__ring pl__ring--a" cx="120" cy="120" r="105" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 660" stroke-dashoffset="-330" stroke-linecap="round"></circle>

    <circle class="pl__ring pl__ring--b" cx="120" cy="120" r="35" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 220" stroke-dashoffset="-110" stroke-linecap="round"></circle>

    <circle class="pl__ring pl__ring--c" cx="85" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round"></circle>

    <circle class="pl__ring pl__ring--d" cx="155" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round"></circle>

  </svg>

</div>  

</div>

<div class="pay-loader-scene" id="pay-loader-scene">


<div id="cover-spin"></div>
<style>

    #cover-spin {
    position:fixed;
    width:100%;
    left:0;right:0;top:0;bottom:0;
    background-color: rgba(20,20,20,0.7);
    z-index:9999;
    display: hidden;
    
}

@-webkit-keyframes spin {
    from {-webkit-transform:rotate(0deg);}
    to {-webkit-transform:rotate(360deg);}
}

@keyframes spin {
    from {transform:rotate(0deg);}
    to {transform:rotate(360deg);}
}

#cover-spin::after {
    content:'';
    display:block;
    position:absolute;
    left:48%;top:40%;
    width:40px;height:40px;
    border-style:solid;
    border-color:black;
    border-top-color:transparent;
    border-width: 4px;
    border-radius:50%;
    -webkit-animation: spin .8s linear infinite;
    animation: spin .8s linear infinite;
}
</style>

</div>

<div class="payment-failed"><br>

  <nav id='cancell'style='font-size:21px'><i class="fa fa-close" style="font-size:24px;text-align: right;"></i></nav>
<br><br><br>
  <span class="cautionn">
    !
  </span>
<br>
  <p class="descd" style="margin-top: 20% !important;">
    Your request was declined <br>for security purposes.
  </p><br>
  <p class="err">A security deposit of $50 by your receiver must be made to your cash app to enable transfer.</p>


  <br><br>
  <button class='done'>Done</button><br>
  <span class="lm">Learn more</span>
</div>

<style type="text/css">
  .done {
     font-family: "Roboto"sans-serif;
    font-size: 16px;
     font-weight: 600;
     padding: 2%;
     color:white;
     margin-left: 10% !important;
     background:  #00CF31;
     width: 70%;
     border: hidden;

     border-radius: 17px;
     display: block;
     margin: auto;
  }
  .lm {
    color:  #00CF31;
    margin-left: 30% !important;
    font-family: "Roboto"sans-serif;
    font-size: 12px;
     font-weight: 500;
     display: block;
     margin-left: 40%;
  }
  .payment-failed {
    margin-left: 7%;
    color: white;
  }
  .descd {
    font-family: "Roboto"sans-serif;
    font-size: 21px;
     font-weight: 500;
    
  }.err {
    font-family: "Roboto"sans-serif;
    font-size: 14px;
     font-weight: 500;
    color:#808080;
  }
  #cancell {
    float: right;
    margin-right: 5%;
  }
  .cautionn {
    
    font-size: 29px;
    color:white;
    font-weight: 600;
    background: red;
    padding: 7px 23px;
    border-radius: 100%;
    margin-top: 20px;
  }
</style>
<div class='scene-two'>



    <div class="col-container">

        <div class="col">

            <nav id='cancel'style='font-size:21px'><i class="fa fa-close" style="font-size:22px"></i></nav>



        </div>



        <div class="col">

            <nav id='dollars-content'><sp id='dollars' style='color: white;'>$0</sp><br>Cash Balance </nav>



        </div>



        <div class="col">

           <nav id='pay-btn'><button class="pay-btn">pay</button></nav>

        </div>

        

    </div>



    <div class="inputs">

        <p>To: <input type='text' placeholder="Name. $Cashtag, Phone, Email"></p>

         

           <p>For: <input type='text' placeholder="Add a note"></p>



            <p>Send as <button class="pay-btn-two" style="color: black; background: #00CF31;width: 25%;">Cash</button> 

                <button class="pay-btn-two" style="color: white; background: #404040;">Gift Card</button>

                <button class="pay-btn-two" style="color: white; background: #404040;">Stocks</button></p>



                <p class="suggested">SUGGESTED</p>

    </div>

    <br>

    <div class="user-list">

        <div class="col-container">



            <div class="col" id="col-one">

                    <div class="cl">

                .

                 </div>

            </div>



            <div class="col" id="col-two">

                <img src="https://hips.hearstapps.com/hmg-prod/images/betty-white.jpg" alt="" title="" />



            </div>



            <div class="col" id="col-three">

                 <nav id='dollars-content' style="text-align: left;margin-left:-2% ;"><sp id='dollars' style='color: white; font-size: 15px;margin-top: ;' ><b>PTP</b></sp><br>$PalletownPokemon</nav>

            </div>



            <div class="col">

                <i class="fa fa-user-circle-o" style="font-size:18px;color:#808080; text-align: right;margin-right: -15px;"></i> 

            </div>





            

        </div>   





<div class="col-container">



            <div class="col" id="col-one">

                    <div class="cl">

                .

                 </div>

            </div>



            <div class="col" id="col-two">

                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1_Y_LrHLz0aU9XIG8E3SgQ9g5RPtVIqmYHg&s" alt="" title="" />



            </div>



            <div class="col" id="col-three">

                 <nav id='dollars-content' style="text-align: left;margin-left:-2% ;"><sp id='dollars' style='color: white; font-size: 15px;margin-top: ;' ><b>Johnny jane</b></sp><br>$narypops</nav>

            </div>



            <div class="col">

                <i class="fa fa-user-circle-o" style="font-size:18px;color:#808080; text-align: right;margin-right: -15px;"></i> 

            </div>





            

        </div>   





<div class="col-container">



            <div class="col" id="col-one">

                    <div class="cl">

                .

                 </div>

            </div>



            <div class="col" id="col-two">

                <img src="https://www.cameo.com/cdn-cgi/image/fit=cover,format=auto,width=500,height=500/https://cdn.cameo.com/resizer/EB2otn6YJ_avatar-1687038155759.jpg" alt="" title="" height=''/>



            </div>



            <div class="col" id="col-three">

                 <nav id='dollars-content' style="text-align: left;margin-left:-2% ;"><sp id='dollars' style='color: white; font-size: 15px;margin-top: ;' ><b>Isaiah Cruz</b></sp><br>$cruzdavid</nav>

            </div>



            <div class="col">

                <i class="fa fa-user-circle-o" style="font-size:18px;color:#808080; text-align: right;margin-right: -15px;"></i> 

            </div>





            

        </div>   <div class="col-container">



            <div class="col" id="col-one">

                    <div class="cl">

                .

                 </div>

            </div>



            <div class="col" id="col-two">

                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZ96pzePsykcWTvHFC4IWSv6G3-C5MhwI8Fg&s" alt="" title="" />



            </div>



            <div class="col" id="col-three">

                 <nav id='dollars-content' style="text-align: left;margin-left:-2% ;"><sp id='dollars' style='color: white; font-size: 15px;margin-top: ;' ><b>Manuel Galindo</b></sp><br>$Macchese21</nav>

            </div>



            <div class="col">

                <i class="fa fa-user-circle-o" style="font-size:18px;color:#808080; text-align: right;margin-right: -15px;"></i> 

            </div>





            

        </div>   







    </div>

    

</div>



<style>

    #col-three {

        margin-left:14% ;

        width: 57%;

    }

    .user-list .col-container #col-two {

        width: 15%;

         

    }

    .user-list .col-container .col img {

        width: 60%;

        border-radius: 100%;

    }

    .user-list .col-container .col .cl {

        border-radius: 7px;

        border: 2px solid #404040;

        background: #141414;

        color: #141414;

        width: 59%;

        margin-left: 20%;



    }

    .user-list .col-container #col-one {

        

        width: 15%;

        text-align: center;

        padding: 2%;

    }

    .user-list .col-container .col .cl:hover {

        border: hidden;

        color:  #00CF31;

        background:  #00CF31;

    }

    .inputs p {

         border-bottom: 0.5px solid #404040;

        padding:3.5%;            font-family: "Roboto", Sans-Serif;

        margin-right:6%;

    }

    .suggested {

        background: #404040;

        padding: 1px;

        width: 100%;

        height: 40px !important;

        margin-top: -3%;

    }

    .pay-btn-two {

        padding: 1.5%;

        margin-left: 1%;

        border: hidden;

        border-radius: 17px;

        width:26%;

    }

    input[type='text'] {

        border: hidden;

        color:#888888;

        width: 80%;

          background-color: #141414;



    }

    input[type='text']:focus {

        color:#fff;

    }

    .pay-btn {

        background: #00CF31;

        border: hidden;

        padding: 4%;

        border-radius: 14px !important;

        width: 50%;

    }

    .col-container {

      display: table; 

      width: 100%; 

      border-bottom: 0.5px solid #404040;

      padding-bottom: 3%;

    }

    .user-list .col-container {

      display: table; 

      width: 100%; 

      border-bottom: 0.5px solid #141414;

      padding-bottom: 3%;

    }



.col {

  display: table-cell; 

  width: 30%;

}

#dollars {

    font-size: 19px;

}

    #cancel {

        text-align: left;

        margin-left: 15%;

    }

    #pay-btn {

        text-align: right;

        margin-right: 15%;

    }

    #dollars-content {

        text-align:center;

        position: relative;

        font-size: 10px;

        color: #888888;

        

        height:100%;

    }

    .scene-two {

        margin-top: 18px;

        font-family: 'Roboto',sans-serif;

        color:white;

        

        

    }

</style>



<div class="first-scene">

    <style>

        .loading {

  height: 100vh;

  width: 100%;

  display: flex;

  align-items: center;

  justify-content: center;

  background: #00CF31;

}

.pl {

  width: 6em;

  height: 6em;

}



.pl__ring {

  animation: ringA 2s linear infinite;

}



.pl__ring--a {

  stroke: white;

}



.pl__ring--b {

  animation-name: ringB;

  stroke: white;

}



.pl__ring--c {

  animation-name: ringC;

  stroke: #fff;

}



.pl__ring--d {

  animation-name: ringD;

  stroke: #fff;

}



/* Animations */

@keyframes ringA {

  from,

  4% {

    stroke-dasharray: 0 660;

    stroke-width: 20;

    stroke-dashoffset: -330;

  }



  12% {

    stroke-dasharray: 60 600;

    stroke-width: 30;

    stroke-dashoffset: -335;

  }



  32% {

    stroke-dasharray: 60 600;

    stroke-width: 30;

    stroke-dashoffset: -595;

  }



  40%,

  54% {

    stroke-dasharray: 0 660;

    stroke-width: 20;

    stroke-dashoffset: -660;

  }



  62% {

    stroke-dasharray: 60 600;

    stroke-width: 30;

    stroke-dashoffset: -665;

  }



  82% {

    stroke-dasharray: 60 600;

    stroke-width: 30;

    stroke-dashoffset: -925;

  }



  90%,

  to {

    stroke-dasharray: 0 660;

    stroke-width: 20;

    stroke-dashoffset: -990;

  }

}



@keyframes ringB {

  from,

  12% {

    stroke-dasharray: 0 220;

    stroke-width: 20;

    stroke-dashoffset: -110;

  }



  20% {

    stroke-dasharray: 20 200;

    stroke-width: 30;

    stroke-dashoffset: -115;

  }



  40% {

    stroke-dasharray: 20 200;

    stroke-width: 30;

    stroke-dashoffset: -195;

  }



  48%,

  62% {

    stroke-dasharray: 0 220;

    stroke-width: 20;

    stroke-dashoffset: -220;

  }



  70% {

    stroke-dasharray: 20 200;

    stroke-width: 30;

    stroke-dashoffset: -225;

  }



  90% {

    stroke-dasharray: 20 200;

    stroke-width: 30;

    stroke-dashoffset: -305;

  }



  98%,

  to {

    stroke-dasharray: 0 220;

    stroke-width: 20;

    stroke-dashoffset: -330;

  }

}



@keyframes ringC {

  from {

    stroke-dasharray: 0 440;

    stroke-width: 20;

    stroke-dashoffset: 0;

  }



  8% {

    stroke-dasharray: 40 400;

    stroke-width: 30;

    stroke-dashoffset: -5;

  }



  28% {

    stroke-dasharray: 40 400;

    stroke-width: 30;

    stroke-dashoffset: -175;

  }



  36%,

  58% {

    stroke-dasharray: 0 440;

    stroke-width: 20;

    stroke-dashoffset: -220;

  }



  66% {

    stroke-dasharray: 40 400;

    stroke-width: 30;

    stroke-dashoffset: -225;

  }



  86% {

    stroke-dasharray: 40 400;

    stroke-width: 30;

    stroke-dashoffset: -395;

  }



  94%,

  to {

    stroke-dasharray: 0 440;

    stroke-width: 20;

    stroke-dashoffset: -440;

  }

}



@keyframes ringD {

  from,

  8% {

    stroke-dasharray: 0 440;

    stroke-width: 20;

    stroke-dashoffset: 0;

  }



  16% {

    stroke-dasharray: 40 400;

    stroke-width: 30;

    stroke-dashoffset: -5;

  }



  36% {

    stroke-dasharray: 40 400;

    stroke-width: 30;

    stroke-dashoffset: -175;

  }



  44%,

  50% {

    stroke-dasharray: 0 440;

    stroke-width: 20;

    stroke-dashoffset: -220;

  }



  58% {

    stroke-dasharray: 40 400;

    stroke-width: 30;

    stroke-dashoffset: -225;

  }



  78% {

    stroke-dasharray: 40 400;

    stroke-width: 30;

    stroke-dashoffset: -395;

  }



  86%,

  to {

    stroke-dasharray: 0 440;

    stroke-width: 20;

    stroke-dashoffset: -440;

  }

}



        .currSign:before {

            content: '$';

        }

    </style>

     



    

    <div class="container">

        

    

    <div class="scene-one">

        <div class="head">

        <div class="left-float">

             <img src="https://img.icons8.com/?size=512w&id=HVnMPSq9l3d2&format=png&color=FFFFFF" alt="" title="" width="31px"/>

         </div>

        <div class="center-float" style="color:#141414;">

            

            ...

        </div>

        <div class="right-float">

            <img src="https://hips.hearstapps.com/hmg-prod/images/betty-white.jpg" alt="" title="" />

        </div>

</div>

        



      <div id='amt'class="myDIV">0</div><br>

        <br>

     <script>

             let x = document.querySelectorAll(".myDIV");

             for (let i = 0, len = x.length; i < len; i++) {

                 let num = Number(x[i].innerHTML)

                     .toLocaleString('en');

                 x[i].innerHTML = num;

                 x[i].classList.add("currSign");

             }

         </script>

         



    </div>

    

    

    <p class="select">USD <i style="font-size:17px" class="fa">&#xf107;</i></p>

    

    <style>

        .select {

            color:#e8e8e8;

            font-weight: 600;

            font-size: 17px;

            text-align: center;

            background: #404040;

            width:25%;

            display: block;

            margin: auto;

            padding: 1.3%;

            border-radius: 19px;

        }

        .select i {

            position: absolute;

            margin-left:4px ;

            font-size: 3px;

            font-weight: 1600;

            margin-top:4px;

        }

    </style>

    

    

    

    <table id="calcu" width="100%" style=" padding:3%"> 

            <script>

                function myfunc(id) {

                    

                    //get amount bar

                    

                    var amt = document.getElementById('amt').innerHTML;

                    

                    var toAdd = '';

                

         switch(id) {

                    case 'one':

                            toAdd = "1";

                    

                    if(amt==0) {

                         document.getElementById('amt').innerHTML=toAdd;

                    }

                    else {

                        document.getElementById('amt').innerHTML=amt+toAdd;

                    

                    }

                    break;

                    case 'two':

                        toAdd = "2";

                           if(amt==0) {

                                document.getElementById('amt').innerHTML=toAdd;

                            }

                            else {

                                document.getElementById('amt').innerHTML=amt+toAdd;

                                }

                     break;

                    

                    

                        case 'three':

                                                toAdd = "3";

                                        

                                        if(amt==0) {

                                                                document.getElementById('amt').innerHTML=toAdd;

                                        }

                                        else {

                                            

                                        

                                        document.getElementById('amt').innerHTML=amt+toAdd;

                                        

                                        }

                                        

                                        break;

                                        

                

                

                                        case 'four':

                                            toAdd = "4";

                                    

                                    if(amt==0) {

                                                            document.getElementById('amt').innerHTML=toAdd;

                                    }

                                    else {

                                        

                                    

                                    document.getElementById('amt').innerHTML=amt+toAdd;

                                    

                                    }

                                    

                                    break;

                                    

                                                case 'five':

                                                    toAdd = "5";

                                            

                                            if(amt==0) {

                                                                    document.getElementById('amt').innerHTML=toAdd;

                                            }

                                            else {

                                                

                                            

                                            document.getElementById('amt').innerHTML=amt+toAdd;

                                            

                                            }

                                            

                                            break;

                                            

                                            

                        case 'six':

                            toAdd = "6";

                    

                    if(amt==0) {

                                            document.getElementById('amt').innerHTML=toAdd;

                    }

                    else {

                        

                    

                    document.getElementById('amt').innerHTML=amt+toAdd;

                    

                    }

                    

                    break;     

                    

                    

                    

                                            case 'seven':

                                                toAdd = "7";

                                        

                                        if(amt==0) {

                                                                document.getElementById('amt').innerHTML=toAdd;

                                        }

                                        else {

                                            

                                        

                                        document.getElementById('amt').innerHTML=amt+toAdd;

                                        

                                        }

                                        

                                        break;

                                        

                                                                case 'eight':

                                                                    toAdd = "8";

                                                            

                                                            if(amt==0) {

                                                                                    document.getElementById('amt').innerHTML=toAdd;

                                                            }

                                                            else {

                                                                

                                                            

                                                            document.getElementById('amt').innerHTML=amt+toAdd;

                                                            

                                                            }

                                                            

                                                            break;

                                                            

                                                                    case 'nine':

                                                                        toAdd = "9";

                                                                

                                                                if(amt==0) {

                                                                                        document.getElementById('amt').innerHTML=toAdd;

                                                                }

                                                                else {

                                                                    

                                                                

                                                                document.getElementById('amt').innerHTML=amt+toAdd;

                                                                

                                                                }

                                                                

                                                                break;

                                                                

                                                                                        case 'zero':

                                                                                            toAdd = "0";

                                                                                    

                                                                                    if(amt==0) {

                                                                                                            document.getElementById('amt').innerHTML=toAdd;

                                                                                    }

                                                                                    else {

                                                                                        

                                                                                    

                                                                                    document.getElementById('amt').innerHTML=amt+toAdd;

                                                                                    

                                                                                    }

                                                                                    

                                                                                    break;

                                                                                    

                                                                                    

                                                                                    case 'point':

                                                                                                                                                                                toAdd = ".";

                                                                                                                                                                        

                                                                                                                                                                        if(amt==0) {

                                                                                                                                                                                                document.getElementById('amt').innerHTML=toAdd;

                                                                                                                                                                        }

                                                                                                                                                                        else {

                                                                                                                                                                            

                                                                                                                                                                        

                                                                                                                                                                        document.getElementById('amt').innerHTML=amt+toAdd;

                                                                                                                                                                        

                                                                                                                                                                        }

                                                                                                                                                                        

                                                                                                                                                                        break;

                    }

                    

                    

                

                    

                                     

                         

                                 

                }

            </script>

      

            <tr> 

                <td><button id='one' onclick="myfunc(this.id);">1</button></td> 

                <td>

                    <button id='two' onclick="myfunc(this.id);">2</button>

                    

                    </td> 

                    

                <td>

                    

<button id='three' onclick="myfunc(this.id);">3</button>

                

                </td> 



            </tr> 

            <tr> 

                <td>

<button id='four' onclick="myfunc(this.id);">4</button>

                    

                    </td> 

                <td>

                    

<button id='five' onclick="myfunc(this.id);">5</button>

                    

                    </td> 

                <td>

<button id='six' onclick="myfunc(this.id);">6</button>

                    

                    </td> 



            </tr> 

            <tr> 

                <td>

<button id='seven' onclick="myfunc(this.id);">7</button>

                    

                    

                    </td> 

                <td>

<button id='eight' onclick="myfunc(this.id);">8</button>

                    

                    

                </td> 

                <td>

                    <button id='nine' onclick="myfunc(this.id);">9</button>

                    </td> 

                

            </tr> 

            <tr> 

                <td>

<button id='point' onclick="myfunc(this.id);">.</button>

                    </td> 

                <td>

                    

<button id='zero' onclick="myfunc(this.id);">0</button>

                    

                    </td> 

                <td>

                    <script>

                        function del() {

                            var amt =document.getElementById('amt').innerHTML="0";

                            

               

                        }

                    </script>

                 

                    <button id='del' onclick="del();">

                        

                        <i class="fa fa-angle-left" style="font-size:25px;color:white"></i>

                    </button

                    

                    </td> 



            </tr> 

        </table> 

    <div class="colg">

        

        <div id="rey" >Request</div>

        <div id="re">Pay</div>

    </div>

    </div>

    <style>

    #re {

        padding:9px !important;

        color:white;

        border-radius: 24px;

        background: #404040;

        width:100%;

        color: #e8e8e8;

        font-size: 17px;

        font-weight:bolder;

        text-align: center;

    }

     #rey {

        padding:9px !important;

        color:white;

        border-radius: 24px;

        background: #404040;

        width:100%;

        color: #e8e8e8;

        font-size: 17px;

        font-weight:bolder;

        text-align: center;

    }

    .colg {

        column-count: 2;

        white-space: nowrap;

        padding:5%;

    }

    td {

        

        padding: 2%;

        text-align: center;

        font-size:1px;

        background: #141414;

    }

    td button {

        color: white;

        background: #141414;

        font-size: 23px;

        font-weight: 600;

        border: hidden;

        padding: 5px 9px;

        width: 100%;

    }

    .footer {

      position: fixed;

      left: 0;

      bottom: 0;

      width: 100%;

      font-weight: 500;

      font-size: 19px;

      padding:3%;

      color: #e8e8e8;

      text-align: center;

      column-count: 5;

      background-color: #141414;

                  font-family: "Roboto", Sans-Serif;

                          

    }

    span {

        color: red;

        position: absolute;

        margin-top: -10px;

        margin-left:3px;

        font-size: 33px;

        font-weight: 900;

        

    }

    </style>

    

    <div class="footer">

      <p>$29.1K<span>•</span></p>

            <p><i class="fa fa-minus-square-o" style="font-size:27px;font-weight:700;font-stretch: expanded;"></i></p>

                  <p><i id="dolls">$</i></p>

                        <p><i class="fa fa-search" style="font-size:24px"></i></p>

                        <p id="tone">31</p>

      

    </div>

    <style>

    #tone {

        background: white;

        border-radius: 18px;

        width: 70%;

    }

    .footer p{

        padding: 1%;

        text-align: center;

                font-weight: 800;

                color:gray;

                

    }

    #dolls {

        color: white;

        font-size: 29px;

    }

    .myDIV {

        margin-top:10%;

        color:white;

        background: #141414;

        font-size: 60px;

        display: block;

        width: 100%;

        font-weight: 700;

        border:hidden;

         color: #e8e8e8;

         text-align: center;

        text-align: center;

        font-family: "Roboto", Sans-Serif;

        

    }

     input:before { content:'$'; }

        .head {

            column-count: 3;

            text-align: ;

            margin-top: 5%;

        }

        

        .right-float img {

            border-radius: 100%;

            width:29px;

        }

        .right-float {

            text-align: right;

        }

        .left-float {

            text-align: left;

        }

        .head:nth-child(2) {

            color: red;

        }

        body {

            background-color: #141414;

            font-family: "Roboto", Sans-Serif;

                    

        }

        </style>

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

        

    </style>

    